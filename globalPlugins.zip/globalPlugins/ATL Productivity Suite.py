import globalPluginHandler
import scriptHandler
import keyboardHandler
import wx
import tones

from .atl_logic import about_manager
from .atl_logic import alarm_manager
from .atl_logic import clean_manager
from .atl_logic import launcher_manager
from .atl_logic import power_manager
from .atl_logic import search_manager
from .atl_logic import sentinel_scanner
from .atl_logic.stopwatch_manager import StopwatchManager
from .atl_logic import system_health
from .atl_logic import telemetry_manager
from .atl_logic import weather_manager

class GlobalPlugin(globalPluginHandler.GlobalPlugin):
	def __init__(self):
		super().__init__()
		self.about_mgr = about_manager.AboutManager()
		self.alarm_mgr = alarm_manager.AlarmManager()
		self.clean_mgr = clean_manager.CleanManager()
		self.launcher_mgr = launcher_manager.LauncherManager()
		self.power_mgr = power_manager.PowerManager()
		self.search_mgr = search_manager.SearchManager()
		self.sentinel_mgr = sentinel_scanner.SentinelScanner()
		self.stopwatch_mgr = StopwatchManager()
		self.health_mgr = system_health.SystemHealthManager()
		self.weather_mgr = weather_manager.WeatherManager()
		self.telemetry = telemetry_manager.TelemetryManager()
		self.telemetry.check_and_prompt_consent()

	@scriptHandler.script(description="Checks the current weather automatically.", gesture="kb:nvda+shift+w")
	def script_checkWeather(self, gesture):
		self.weather_mgr.check_default_weather(is_shortcut=True)

	@scriptHandler.script(description="Opens the Alarm Manager menu.", gesture="kb:nvda+shift+a")
	def script_openAlarmMenu(self, gesture):
		wx.CallAfter(self.alarm_mgr.open_menu)

	@scriptHandler.script(description="Opens the ATL System Cleaner menu.", gesture="kb:nvda+shift+c")
	def script_cleanMenu(self, gesture):
		wx.CallAfter(self.clean_mgr.open_menu)

	@scriptHandler.script(description="Opens Google Quick Search.", gesture="kb:nvda+shift+g")
	def script_quickSearch(self, gesture):
		wx.CallAfter(self.search_mgr.open_menu)

	@scriptHandler.script(description="Opens the ATL Enterprise System Diagnostic Engine.", gesture="kb:nvda+shift+h")
	def script_openHealthMenu(self, gesture):
		tones.beep(850, 60)
		wx.CallAfter(self.health_mgr.open_menu)

	@scriptHandler.script(description="Opens the ATL Master Menu.", gesture="kb:nvda+shift+m")
	def script_openMainMenu(self, gesture):
		tones.beep(900, 60)
		wx.CallAfter(self.show_main_menu)

	@scriptHandler.script(description="Opens the About ATL menu.", gesture="kb:nvda+shift+o")
	def script_openAboutMenu(self, gesture):
		tones.beep(1000, 100)
		wx.CallAfter(self.about_mgr.open_menu)

	@scriptHandler.script(description="Opens the Power Manager menu.", gesture="kb:nvda+shift+p")
	def script_openPowerMenu(self, gesture):
		wx.CallAfter(self.power_mgr.open_menu)

	@scriptHandler.script(description="Opens the ATL Quick Launcher config menu.", gesture="kb:nvda+shift+q")
	def script_openLauncherMenu(self, gesture):
		wx.CallAfter(self.launcher_mgr.open_menu)

	def show_main_menu(self):
		options = [
			"1. About ATL",
			"2. Alarm Manager",
			"3. ATL Enterprise System Diagnostic Engine",
			"4. ATL Precision Stopwatch",
			"5. ATL Sentinel Security Scanner",
			"6. ATL Smart Weather Assistant",
			"7. Google Quick Search",
			"8. Power Manager",
			"9. Quick Launcher",
			"10. System Cleaner"
		]
		with wx.SingleChoiceDialog(None, "Select ATL Tool:", "ATL Master Menu", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					wx.CallAfter(self.about_mgr.open_menu)
				elif sel == 1:
					wx.CallAfter(self.alarm_mgr.open_menu)
				elif sel == 2:
					wx.CallAfter(self.health_mgr.open_menu)
				elif sel == 3:
					wx.CallAfter(self.stopwatch_mgr.open_menu)
				elif sel == 4:
					wx.CallAfter(self.sentinel_mgr.open_menu)
				elif sel == 5:
					wx.CallAfter(self.weather_mgr.open_menu)
				elif sel == 6:
					wx.CallAfter(self.search_mgr.open_menu)
				elif sel == 7:
					wx.CallAfter(self.power_mgr.open_menu)
				elif sel == 8:
					wx.CallAfter(self.launcher_mgr.open_menu)
				elif sel == 9:
					wx.CallAfter(self.clean_mgr.open_menu)

	@scriptHandler.script(description="Launches Quick Launcher Slot 1.", gesture="kb:nvda+windows+1")
	def script_launch1(self, gesture):
		self.launcher_mgr.run_slot(1)

	@scriptHandler.script(description="Launches Quick Launcher Slot 2.", gesture="kb:nvda+windows+2")
	def script_launch2(self, gesture):
		self.launcher_mgr.run_slot(2)

	@scriptHandler.script(description="Launches Quick Launcher Slot 3.", gesture="kb:nvda+windows+3")
	def script_launch3(self, gesture):
		self.launcher_mgr.run_slot(3)

	@scriptHandler.script(description="Launches Quick Launcher Slot 4.", gesture="kb:nvda+windows+4")
	def script_launch4(self, gesture):
		self.launcher_mgr.run_slot(4)

	@scriptHandler.script(description="Launches Quick Launcher Slot 5.", gesture="kb:nvda+windows+5")
	def script_launch5(self, gesture):
		self.launcher_mgr.run_slot(5)

	@scriptHandler.script(description="Launches Quick Launcher Slot 6.", gesture="kb:nvda+windows+6")
	def script_launch6(self, gesture):
		self.launcher_mgr.run_slot(6)

	@scriptHandler.script(description="Launches Quick Launcher Slot 7.", gesture="kb:nvda+windows+7")
	def script_launch7(self, gesture):
		self.launcher_mgr.run_slot(7)

	@scriptHandler.script(description="Launches Quick Launcher Slot 8.", gesture="kb:nvda+windows+8")
	def script_launch8(self, gesture):
		self.launcher_mgr.run_slot(8)

	@scriptHandler.script(description="Launches Quick Launcher Slot 9.", gesture="kb:nvda+windows+9")
	def script_launch9(self, gesture):
		self.launcher_mgr.run_slot(9)

	@scriptHandler.script(description="Launches Quick Launcher Slot 0.", gesture="kb:nvda+windows+0")
	def script_launch0(self, gesture):
		self.launcher_mgr.run_slot(0)