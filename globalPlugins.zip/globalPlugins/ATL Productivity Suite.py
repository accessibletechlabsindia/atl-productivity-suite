import globalPluginHandler
import scriptHandler
import keyboardHandler
from datetime import datetime
import webbrowser
import ui
import tones
import api
import os
from .atl_logic import alarm_manager
from .atl_logic import power_manager
from .atl_logic import system_health
from .atl_logic import about_manager
import threading
import time
import json
import wx
import ctypes
import shutil

class GlobalPlugin(globalPluginHandler.GlobalPlugin):
	def __init__(self):
		super().__init__()
		self.alarm_mgr = alarm_manager.AlarmManager()
		self.power_mgr = power_manager.PowerManager()
		self.health_mgr = system_health.SystemHealthManager()
		self.about_mgr = about_manager.AboutManager()

	@scriptHandler.script(description="Opens the Alarm Manager menu.", gesture="kb:nvda+shift+a")
	def script_openAlarmMenu(self, gesture):
		wx.CallAfter(self.alarm_mgr.open_menu)

	@scriptHandler.script(description="Opens the Power Manager menu.", gesture="kb:nvda+shift+p")
	def script_openPowerMenu(self, gesture):
		wx.CallAfter(self.power_mgr.open_menu)

	@scriptHandler.script(description="Opens the System Health Dashboard.", gesture="kb:nvda+shift+h")
	def script_openHealthMenu(self, gesture):
		tones.beep(850, 60)
		wx.CallAfter(self.health_mgr.open_menu)

	@scriptHandler.script(description="Opens the About ATL menu.", gesture="kb:nvda+shift+o")
	def script_openAboutMenu(self, gesture):
		tones.beep(1000, 100)
		wx.CallAfter(self.about_mgr.open_menu)

	@scriptHandler.script(description="Opens the ATL Master Menu.", gesture="kb:nvda+shift+m")
	def script_openMainMenu(self, gesture):
		tones.beep(900, 60)
		wx.CallAfter(self.show_main_menu)

	def show_main_menu(self):
		options = [
			"1. System Health Dashboard",
			"2. System Cleaner",
			"3. Quick Launcher",
			"4. Alarm Manager",
			"5. Power Manager",
			"6. Google Quick Search",
			"7. Text File Reader",
			"8. About ATL"
		]
		with wx.SingleChoiceDialog(None, "Select ATL Tool:", "ATL Master Menu", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					wx.CallAfter(self.health_mgr.open_menu)
				elif sel == 1:
					self.script_cleanMenu(None)
				elif sel == 2:
					self.script_openLauncherMenu(None)
				elif sel == 3:
					wx.CallAfter(self.alarm_mgr.open_menu)
				elif sel == 4:
					wx.CallAfter(self.power_mgr.open_menu)
				elif sel == 5:
					self.script_quickSearch(None)
				elif sel == 6:
					self.script_readFile(None)
				elif sel == 7:
					wx.CallAfter(self.about_mgr.open_menu)

	@scriptHandler.script(description="Reads a text file.", gesture="kb:nvda+shift+r")
	def script_readFile(self, gesture):
		tones.beep(800, 80)
		wx.CallAfter(self.openFileDialog)

	def openFileDialog(self):
		with wx.FileDialog(
			None,
			"Select Text File",
			wildcard="Text Files (*.txt)|*.txt",
			style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST,
		) as dialog:
			if dialog.ShowModal() != wx.ID_OK:
				tones.beep(300, 50)
				ui.message("Canceled")
				return
			path = dialog.GetPath()
			if not os.path.exists(path):
				ui.message("File not found")
				return
			tones.beep(900, 60)
			try:
				with open(path, "r", encoding="utf-8", errors="ignore") as f:
					data = f.read()
			except:
				ui.message("Unable to read file")
				return
			ui.browseableMessage(data, title=os.path.basename(path))
			ui.message("Reading file")


	@scriptHandler.script(description="Opens Google Quick Search.", gesture="kb:nvda+shift+g")
	def script_quickSearch(self, gesture):
		tones.beep(850, 50)
		wx.CallAfter(self.showSearchDialog)

	def showSearchDialog(self):
		with wx.TextEntryDialog(None, "Enter text or URL (Max 500 chars):", "Google Quick Search") as dialog:
			if dialog.ShowModal() == wx.ID_OK:
				query = dialog.GetValue().strip()
				if not query:
					tones.beep(300, 100)
					ui.message("Empty input. Please type something to search.")
					return
				if len(query) > 500:
					tones.beep(300, 100)
					ui.message("Search text is too long. Max 500 characters allowed.")
					return
				tones.beep(950, 50)
				if "." in query and " " not in query:
					ui.message("Opening link")
					if not query.startswith(("http://", "https://")):
						query = "https://" + query
					webbrowser.open(query)
				else:
					ui.message("Searching on Google")
					webbrowser.open(f"https://www.google.com/search?q={query}")
			else:
				tones.beep(400, 50)
				ui.message("Search Canceled")

	@scriptHandler.script(description="Opens the ATL System Cleaner menu.", gesture="kb:nvda+shift+c")
	def script_cleanMenu(self, gesture):
		tones.beep(800, 50)
		options = [
			"1. Windows Junk (Temp and Prefetch)",
			"2. Google Chrome Cache",
			"3. Microsoft Edge Cache",
			"4. Empty Recycle Bin",
			"5. Deep Clean All"
		]
		def show_menu():
			with wx.SingleChoiceDialog(None, "Select Cleaning Task:", "ATL System Cleaner", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					sel = dlg.GetSelection()
					threading.Thread(target=self.execute_clean, args=(sel,), daemon=True).start()
		wx.CallAfter(show_menu)

	def execute_clean(self, selection):
		ui.message("Cleaning started")
		
		is_admin = False
		try:
			is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
		except:
			pass

		targets = []
		local_app_data = os.environ.get('LOCALAPPDATA', '')
		win_dir = os.environ.get('SystemRoot', 'C:\\Windows')
		
		sys_temp = os.environ.get('TEMP')
		win_temp = os.path.join(win_dir, 'Temp')
		prefetch = os.path.join(win_dir, 'Prefetch')
		chrome_cache = os.path.join(local_app_data, "Google\\Chrome\\User Data\\Default\\Cache")
		edge_cache = os.path.join(local_app_data, "Microsoft\\Edge\\User Data\\Default\\Cache")

		if selection in [0, 4]:
			targets.extend([(sys_temp, "User Temp"), (win_temp, "System Temp")])
			if is_admin:
				targets.append((prefetch, "Prefetch"))
			else:
				wx.CallAfter(ui.message, "Skipping Prefetch. Admin rights required.")
				
		if selection in [1, 4]:
			targets.append((chrome_cache, "Chrome Cache"))
		if selection in [2, 4]:
			targets.append((edge_cache, "Edge Cache"))

		actual_bytes_cleared = 0
		dlg_box = []

		def create_dialog():
			dlg = wx.ProgressDialog("ATL System Cleaner", "Starting...", maximum=max(1, len(targets)*100), parent=None, style=wx.PD_SMOOTH | wx.PD_AUTO_HIDE)
			dlg.Show()
			dlg_box.append(dlg)

		wx.CallAfter(create_dialog)
		time.sleep(0.5)

		last_beep_time = time.time()

		for i, (path, name) in enumerate(targets):
			if not path or not os.path.exists(path):
				continue

			def update_msg(msg, val):
				if dlg_box: dlg_box[0].Update(val, msg)

			wx.CallAfter(update_msg, f"Cleaning {name}...", i * 100)
			ui.message(f"Cleaning {name}")

			for root, dirs, files in os.walk(path):
				for f in files:
					current_time = time.time()
					if current_time - last_beep_time >= 1.0:
						tones.beep(1000, 50)
						last_beep_time = current_time

					file_path = os.path.join(root, f)
					try:
						size = os.path.getsize(file_path)
						os.remove(file_path)
						actual_bytes_cleared += size
					except:
						pass
				
				for d in dirs:
					dir_path = os.path.join(root, d)
					try:
						shutil.rmtree(dir_path)
					except:
						pass

			time.sleep(0.5)

		if selection in [3, 4]:
			wx.CallAfter(update_msg, "Emptying Recycle Bin...", len(targets) * 100)
			ui.message("Emptying Recycle Bin")
			try:
				main_hwnd = api.getDesktopObject().windowHandle
				res = ctypes.windll.shell32.SHEmptyRecycleBinW(main_hwnd, None, 7)
				if res == 0:
					tones.beep(1000, 50)
				else:
					ctypes.windll.shell32.SHEmptyRecycleBinW(0, None, 7)
			except:
				pass

		def close_dialog():
			if dlg_box: dlg_box[0].Destroy()

		wx.CallAfter(close_dialog)

		mb = round(actual_bytes_cleared / (1024 * 1024), 2)
		if mb > 1024:
			final_msg = f"Done! Real cleared memory: {round(mb/1024, 2)} GB."
		else:
			final_msg = f"Done! Real cleared memory: {mb} MB."

		ui.message(final_msg)
		tones.beep(800, 100)
		tones.beep(1000, 150)
		wx.CallAfter(wx.MessageBox, final_msg, "Cleaning Complete", wx.OK | wx.ICON_INFORMATION)

	def _get_launcher_path(self):
		return os.path.join(os.path.dirname(__file__), "launcher_settings.json")

	def _load_launcher_data(self):
		path = self._get_launcher_path()
		if os.path.exists(path):
			with open(path, "r") as f:
				return json.load(f)
		return {str(i): "" for i in range(10)}

	def _save_launcher_data(self, data):
		with open(self._get_launcher_path(), "w") as f:
			json.dump(data, f)

	def run_slot(self, slot_num):
		data = self._load_launcher_data()
		path = data.get(str(slot_num), "")
		if not path:
			ui.message(f"Slot {slot_num} is empty")
			return
		target = path
		if "." in target and not target.startswith(("http://", "https://")) and "\\" not in target:
			target = "https://" + target
		try:
			if target.startswith(("http://", "https://")):
				webbrowser.open(target)
			else:
				os.startfile(target)
			ui.message(f"Opening Slot {slot_num}")
		except:
			ui.message("Error: Could not open")

	@scriptHandler.script(description="Opens the ATL Quick Launcher config menu.", gesture="kb:nvda+shift+q")
	def script_openLauncherMenu(self, gesture):
		data = self._load_launcher_data()
		options = [f"Slot {i}: {data[str(i)] if data[str(i)] else 'Empty'}" for i in range(10)]
		def on_select():
			with wx.SingleChoiceDialog(None, "Select a slot to configure:", "ATL Quick Launcher", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					index = dlg.GetSelection()
					self.configure_slot(index)
		wx.CallAfter(on_select)

	def configure_slot(self, index):
		options = ["Select Application (File)", "Select Folder", "Manual Entry / Web Link", "Clear Slot"]
		def show_menu():
			with wx.SingleChoiceDialog(None, f"Choose action for Slot {index}:", "Configure Slot", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					selection = dlg.GetSelection()
					if selection == 0: self._browse_file(index)
					elif selection == 1: self._browse_folder(index)
					elif selection == 2: self._manual_entry(index)
					elif selection == 3: self._clear_slot(index)
		wx.CallAfter(show_menu)

	def _browse_file(self, index):
		def open_file():
			with wx.FileDialog(None, "Select Application or File", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetPath())
		wx.CallAfter(open_file)

	def _browse_folder(self, index):
		def open_dir():
			with wx.DirDialog(None, "Select Folder", style=wx.DD_DEFAULT_STYLE) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetPath())
		wx.CallAfter(open_dir)

	def _manual_entry(self, index):
		data = self._load_launcher_data()
		current = data.get(str(index), "")
		def enter_text():
			with wx.TextEntryDialog(None, "Enter URL or Path:", "Manual Entry", current) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetValue().strip())
		wx.CallAfter(enter_text)

	def _clear_slot(self, index):
		self._update_slot(index, "")
		ui.message(f"Slot {index} cleared")

	def _update_slot(self, index, path):
		data = self._load_launcher_data()
		data[str(index)] = path
		self._save_launcher_data(data)
		if path: ui.message(f"Slot {index} updated")
	@scriptHandler.script(description="Launches Quick Launcher Slot 1.", gesture="kb:nvda+windows+1")
	def script_launch1(self, gesture):
		self.run_slot(1)
	@scriptHandler.script(description="Launches Quick Launcher Slot 2.", gesture="kb:nvda+windows+2")
	def script_launch2(self, gesture):
		self.run_slot(2)
	@scriptHandler.script(description="Launches Quick Launcher Slot 3.", gesture="kb:nvda+windows+3")
	def script_launch3(self, gesture):
		self.run_slot(3)
	@scriptHandler.script(description="Launches Quick Launcher Slot 4.", gesture="kb:nvda+windows+4")
	def script_launch4(self, gesture):
		self.run_slot(4)
	@scriptHandler.script(description="Launches Quick Launcher Slot 5.", gesture="kb:nvda+windows+5")
	def script_launch5(self, gesture):
		self.run_slot(5)
	@scriptHandler.script(description="Launches Quick Launcher Slot 6.", gesture="kb:nvda+windows+6")
	def script_launch6(self, gesture):
		self.run_slot(6)
	@scriptHandler.script(description="Launches Quick Launcher Slot 7.", gesture="kb:nvda+windows+7")
	def script_launch7(self, gesture):
		self.run_slot(7)
	@scriptHandler.script(description="Launches Quick Launcher Slot 8.", gesture="kb:nvda+windows+8")
	def script_launch8(self, gesture):
		self.run_slot(8)
	@scriptHandler.script(description="Launches Quick Launcher Slot 9.", gesture="kb:nvda+windows+9")
	def script_launch9(self, gesture):
		self.run_slot(9)
	@scriptHandler.script(description="Launches Quick Launcher Slot 0.", gesture="kb:nvda+windows+0")
	def script_launch0(self, gesture):
		self.run_slot(0)