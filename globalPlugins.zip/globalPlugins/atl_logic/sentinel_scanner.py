import os
import json
import time
import threading
import urllib.request
import urllib.parse
import urllib.error
import hashlib
import wx
import ui
import tones
from . import telemetry_manager

class SentinelScanner:
	def __init__(self):
		self.default_api_key = "d6798d26916a63107d800cdf2e7bfbf731cda797e74d9ff0e1a476732a6c35b2"
		self.base_url = "https://www.virustotal.com/api/v3"
		self.addon_dir = os.path.dirname(__file__)
		self.master_path = os.path.join(self.addon_dir, "atl_master_settings.json")
		self.api_key = self._load_api_key()
		self.history = self._load_history()
		self.telemetry = telemetry_manager.TelemetryManager()

	def _load_api_key(self):
		if os.path.exists(self.master_path):
			try:
				with open(self.master_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("sentinel_api_key", self.default_api_key)
			except:
				return self.default_api_key
		return self.default_api_key

	def _save_api_key(self, key):
		master_data = {}
		if os.path.exists(self.master_path):
			try:
				with open(self.master_path, "r", encoding="utf-8") as f:
					loaded_data = json.load(f)
					if isinstance(loaded_data, dict):
						master_data = loaded_data
			except:
				pass
		master_data["sentinel_api_key"] = key
		try:
			with open(self.master_path, "w", encoding="utf-8") as f:
				json.dump(master_data, f)
		except:
			pass

	def _load_history(self):
		if os.path.exists(self.master_path):
			try:
				with open(self.master_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("sentinel_history", [])
			except:
				return []
		return []

	def _save_history(self):
		master_data = {}
		if os.path.exists(self.master_path):
			try:
				with open(self.master_path, "r", encoding="utf-8") as f:
					loaded_data = json.load(f)
					if isinstance(loaded_data, dict):
						master_data = loaded_data
			except:
				pass
		master_data["sentinel_history"] = self.history
		try:
			with open(self.master_path, "w", encoding="utf-8") as f:
				json.dump(master_data, f)
		except:
			pass

	def _add_history(self, title, status, details):
		record = {
			"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
			"title": title,
			"status": status,
			"details": details
		}
		self.history.insert(0, record)
		self._save_history()

	def _make_request(self, method, endpoint, data=None, headers=None, timeout=30):
		if endpoint.startswith("http"):
			url = endpoint
		else:
			url = f"{self.base_url}/{endpoint}"
		req_headers = {"x-apikey": self.api_key}
		if headers:
			req_headers.update(headers)
		req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
		try:
			with urllib.request.urlopen(req, timeout=timeout) as response:
				return json.loads(response.read().decode("utf-8"))
		except urllib.error.HTTPError as e:
			if e.code == 404:
				return None
			elif e.code == 401:
				return {"error": "Invalid API Key. Please update your key in the settings."}
			elif e.code == 429:
				return {"error": "API Rate Limit Exceeded. Try again later or use your own API Key."}
			return {"error": f"HTTP Error {e.code}"}
		except Exception as e:
			return {"error": str(e)}

	def _get_file_hash(self, filepath):
		sha256 = hashlib.sha256()
		try:
			with open(filepath, "rb") as f:
				for chunk in iter(lambda: f.read(4096), b""):
					sha256.update(chunk)
			return sha256.hexdigest()
		except:
			return None

	def open_menu(self):
		options = [
			"1. Scan Local File (Deep Scan)",
			"2. Scan Web URL, Domain or IP Address",
			"3. View Scan History",
			"4. Clear Scan History",
			"5. Scanner Settings (API Key)"
		]
		with wx.SingleChoiceDialog(None, "Select ATL Sentinel Action:", "ATL Sentinel Security", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					wx.CallAfter(self._select_and_scan_file)
				elif sel == 1:
					wx.CallAfter(self._scan_url_dialog)
				elif sel == 2:
					wx.CallAfter(self._view_history)
				elif sel == 3:
					wx.CallAfter(self._clear_history)
				elif sel == 4:
					wx.CallAfter(self._open_settings)

	def _clear_history(self):
		if not self.history:
			tones.beep(400, 100)
			wx.MessageBox("Scan history is already empty. Nothing to clear.", "History Empty", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
		else:
			self.history = []
			self._save_history()
			tones.beep(500, 100)
			wx.MessageBox("Scan history successfully cleared.", "Success", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)

	def _open_settings(self):
		options = [
			"How to get a Free API Key (Tutorial)",
			"Enter your Custom API Key",
			"Reset to Default ATL Key"
		]
		with wx.SingleChoiceDialog(None, "ATL Sentinel Settings:", "Scanner Settings", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					self._show_tutorial()
				elif sel == 1:
					self._enter_custom_key()
				elif sel == 2:
					self.api_key = self.default_api_key
					self._save_api_key(self.api_key)
					tones.beep(800, 100)
					wx.MessageBox("Successfully reset to the default ATL API Key.", "Key Reset", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)

	def _show_tutorial(self):
		tut = (
			"How to get a Free VirusTotal API Key:\n\n"
			"1. Open your web browser and navigate to www.virustotal.com.\n"
			"2. Click on 'Join Community' or 'Sign Up' to create a free account.\n"
			"3. Verify your email address by clicking the link sent to your inbox.\n"
			"4. Sign in to VirusTotal, open your User Profile menu at the top right, and select 'API Key'.\n"
			"5. Copy the long text under 'General API key'.\n"
			"6. Come back to this addon's settings and paste it into the 'Enter your Custom API Key' option."
		)
		def show_msg():
			ui.browseableMessage(tut, title="API Key Tutorial")
		wx.CallAfter(show_msg)

	def _enter_custom_key(self):
		with wx.TextEntryDialog(None, "Paste your 64-character VirusTotal API Key here:", "Custom API Key Setup") as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				new_key = dlg.GetValue().strip()
				if new_key:
					threading.Thread(target=self._validate_and_save_key, args=(new_key,), daemon=True).start()

	def _validate_and_save_key(self, new_key):
		wx.CallAfter(ui.message, "Validating your API Key securely...")
		
		pd = []
		def show_pd():
			d = wx.ProgressDialog("API Validation", "Validating your API Key securely...", maximum=100, style=wx.PD_APP_MODAL | wx.PD_AUTO_HIDE | wx.STAY_ON_TOP)
			d.Pulse()
			pd.append(d)
		wx.CallAfter(show_pd)

		url = f"{self.base_url}/ip_addresses/1.1.1.1"
		req = urllib.request.Request(url, headers={"x-apikey": new_key}, method="GET")
		try:
			urllib.request.urlopen(req, timeout=15)
			self.api_key = new_key
			self._save_api_key(new_key)
			wx.CallAfter(lambda: pd[0].Destroy() if pd else None)
			tones.beep(1000, 150)
			wx.CallAfter(wx.MessageBox, "Success: Your API Key is valid and successfully activated!", "Key Activated", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
		except urllib.error.HTTPError as e:
			wx.CallAfter(lambda: pd[0].Destroy() if pd else None)
			tones.beep(400, 100)
			if e.code == 401:
				wx.CallAfter(wx.MessageBox, "Error: Invalid API Key. Please check the key and try again.", "Invalid Key", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			else:
				wx.CallAfter(wx.MessageBox, f"Validation failed. HTTP Error {e.code}", "Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
		except Exception as e:
			wx.CallAfter(lambda: pd[0].Destroy() if pd else None)
			tones.beep(400, 100)
			wx.CallAfter(wx.MessageBox, f"Network error during validation: {str(e)}", "Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)

	def _select_and_scan_file(self):
		with wx.FileDialog(None, "Select File to Scan", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				filepath = dlg.GetPath()
				threading.Thread(target=self._process_file_scan, args=(filepath,), daemon=True).start()

	def _process_file_scan(self, filepath):
		filename = os.path.basename(filepath)
		
		try:
			file_size = os.path.getsize(filepath)
		except:
			wx.CallAfter(wx.MessageBox, "Unable to read file for scanning.", "Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return

		if file_size > 681574400:
			wx.CallAfter(wx.MessageBox, "File is too large. Maximum supported size for Deep Scan is 650 MB.", "Size Limit Exceeded", wx.OK | wx.ICON_WARNING | wx.STAY_ON_TOP)
			return

		self.telemetry.track("Sentinel Scanner - File Scanned")
		wx.CallAfter(ui.message, "Calculating file hash, please wait.")
		file_hash = self._get_file_hash(filepath)
		
		if not file_hash:
			wx.CallAfter(wx.MessageBox, "Unable to read file for scanning.", "Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return

		wx.CallAfter(ui.message, "Checking file fingerprint with VirusTotal.")
		res = self._make_request("GET", f"files/{file_hash}")

		if res and "error" in res:
			wx.CallAfter(wx.MessageBox, res["error"], "API Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return

		if res is None:
			def ask_upload():
				dlg = wx.MessageDialog(None, "File fingerprint not found in database. Do you want to securely upload this file for a deep scan? This may take some time depending on file size.", "Deep Scan Required", wx.YES_NO | wx.ICON_QUESTION | wx.STAY_ON_TOP)
				if dlg.ShowModal() == wx.ID_YES:
					threading.Thread(target=self._upload_and_scan_file, args=(filepath, file_size), daemon=True).start()
				dlg.Destroy()
			wx.CallAfter(ask_upload)
		else:
			self._parse_and_show_results(res, filename, "File")

	def _upload_and_scan_file(self, filepath, file_size):
		filename = os.path.basename(filepath)
		
		endpoint = "files"
		if file_size > 33554432:
			wx.CallAfter(ui.message, "Large file detected. Requesting secure enterprise route.")
			url_res = self._make_request("GET", "files/upload_url")
			if url_res and "data" in url_res:
				endpoint = url_res["data"]
			else:
				wx.CallAfter(wx.MessageBox, "Failed to get special upload URL for large file.", "API Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
				return

		boundary = "----ATLBoundary7MA4YW"
		body = []
		body.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n".encode("utf-8"))
		
		try:
			with open(filepath, "rb") as f:
				body.append(f.read())
		except:
			wx.CallAfter(wx.MessageBox, "Error reading file for upload.", "Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return
			
		body.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
		data = b"".join(body)
		headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}

		self.pd = None
		def show_pd():
			self.pd = wx.ProgressDialog("ATL Sentinel Security", "Securely uploading file to VirusTotal...", maximum=100, style=wx.PD_SMOOTH | wx.PD_AUTO_HIDE | wx.STAY_ON_TOP)
			self.pd.Pulse("Uploading...")
		wx.CallAfter(show_pd)

		self.is_uploading = True
		def upload_speaker():
			while self.is_uploading:
				wx.CallAfter(ui.message, f"Uploading your file {filename} to VirusTotal. Please wait.")
				if self.pd:
					wx.CallAfter(self.pd.Pulse, f"Uploading {filename}...")
				time.sleep(20)
		threading.Thread(target=upload_speaker, daemon=True).start()

		res = self._make_request("POST", endpoint, data=data, headers=headers, timeout=600)
		
		self.is_uploading = False
		wx.CallAfter(lambda: self.pd.Destroy() if self.pd else None)

		if res and "error" in res:
			wx.CallAfter(wx.MessageBox, res["error"], "Upload Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return
			
		if "data" in res and "id" in res["data"]:
			analysis_id = res["data"]["id"]
			self._poll_analysis(analysis_id, filename, "File")

	def _scan_url_dialog(self):
		with wx.TextEntryDialog(None, "Enter URL, Domain, or IP Address to scan:", "ATL Universal Target Scanner") as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				url = dlg.GetValue().strip()
				if url:
					threading.Thread(target=self._process_url_scan, args=(url,), daemon=True).start()

	def _process_url_scan(self, url):
		self.telemetry.track("Sentinel Scanner - URL/IP Scanned")
		wx.CallAfter(ui.message, "Submitting target to VirusTotal.")
		data = urllib.parse.urlencode({"url": url}).encode("utf-8")
		headers = {"Content-Type": "application/x-www-form-urlencoded"}
		res = self._make_request("POST", "urls", data=data, headers=headers)
		
		if res and "error" in res:
			wx.CallAfter(wx.MessageBox, res["error"], "API Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
			return
			
		if "data" in res and "id" in res["data"]:
			analysis_id = res["data"]["id"]
			self._poll_analysis(analysis_id, url, "URL / IP / Domain")

	def _poll_analysis(self, analysis_id, target_name, target_type):
		max_attempts = 120
		for attempt in range(max_attempts):
			wx.CallAfter(ui.message, f"Scanning {target_name} with 70+ security engines. Please wait.")
			time.sleep(20)
			res = self._make_request("GET", f"analyses/{analysis_id}")
			if res and "data" in res and "attributes" in res["data"]:
				status = res["data"]["attributes"]["status"]
				if status == "completed":
					self._parse_and_show_results(res, target_name, target_type, is_analysis=True)
					return
		wx.CallAfter(wx.MessageBox, "Analysis timed out. Please check your history later.", "Timeout", wx.OK | wx.ICON_WARNING | wx.STAY_ON_TOP)

	def _parse_and_show_results(self, res, target_name, target_type, is_analysis=False):
		try:
			if is_analysis:
				stats = res["data"]["attributes"]["stats"]
			else:
				stats = res["data"]["attributes"]["last_analysis_stats"]
				
			malicious = stats.get("malicious", 0)
			suspicious = stats.get("suspicious", 0)
			undetected = stats.get("undetected", 0)
			harmless = stats.get("harmless", 0)
			total = malicious + suspicious + undetected + harmless

			if malicious >= 3:
				verdict = "MALICIOUS"
			elif malicious > 0 or suspicious > 0:
				verdict = "SUSPICIOUS"
			else:
				verdict = "SAFE"

			tones.beep(1000, 150)

			report = (
				f"ATL Sentinel Security Report\n"
				f"--------------------------------\n"
				f"Target: {target_name}\n"
				f"Type: {target_type}\n"
				f"Verdict: {verdict}\n\n"
				f"Detection Ratio: {malicious} out of {total} security vendors flagged this as malicious.\n\n"
				f"Detailed Analysis Stats:\n"
				f"- Malicious: {malicious}\n"
				f"- Suspicious: {suspicious}\n"
				f"- Harmless: {harmless}\n"
				f"- Undetected: {undetected}\n\n"
				f"Report generated securely by Accessible Tech Labs India."
			)
			self._add_history(target_name, verdict, report)
			wx.CallAfter(self._show_report_dialog, report, verdict)
		except Exception as e:
			wx.CallAfter(wx.MessageBox, f"Error parsing report: {str(e)}", "Data Error", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)

	def _show_report_dialog(self, report, verdict):
		dlg = wx.Dialog(None, title=f"Scan Result: {verdict}", size=(500, 400), style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP)
		sz = wx.BoxSizer(wx.VERTICAL)
		tc = wx.TextCtrl(dlg, style=wx.TE_MULTILINE | wx.TE_READONLY)
		tc.SetValue(report)
		sz.Add(tc, 1, wx.EXPAND | wx.ALL, 10)
		btn = wx.Button(dlg, wx.ID_OK, label="Close Report")
		sz.Add(btn, 0, wx.CENTER | wx.BOTTOM, 10)
		dlg.SetSizer(sz)
		dlg.ShowModal()
		dlg.Destroy()

	def _view_history(self):
		if not self.history:
			wx.MessageBox("No scan history found.", "History Empty", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
			return
		options = [f"{item['timestamp']} - {item['title']} [{item['status']}]" for item in self.history]
		with wx.SingleChoiceDialog(None, "Select a record to view details:", "ATL Sentinel History", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				idx = dlg.GetSelection()
				record = self.history[idx]
				self._show_report_dialog(record["details"], record["status"])