import os
import json
import time
import threading
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime
import wx
import ui
import tones
from . import telemetry_manager

class WeatherManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.addon_dir = os.path.dirname(__file__)
		self.settings_path = os.path.join(self.addon_dir, "atl_master_settings.json")
		self.lang = "Hindi"
		self.default_city = ""
		self._load_config()
		
		self.wmo_codes = {
			0: {"en": "Clear sky", "hi": "बिल्कुल साफ़"},
			1: {"en": "Mainly clear", "hi": "मुख्य रूप से साफ़"},
			2: {"en": "Partly cloudy", "hi": "आंशिक रूप से बादल"},
			3: {"en": "Overcast", "hi": "बादलों से घिरा हुआ"},
			45: {"en": "Fog", "hi": "कोहरा"},
			48: {"en": "Depositing rime fog", "hi": "घना कोहरा"},
			51: {"en": "Light drizzle", "hi": "हल्की बूंदाबांदी"},
			53: {"en": "Moderate drizzle", "hi": "मध्यम बूंदाबांदी"},
			55: {"en": "Dense drizzle", "hi": "घनी बूंदाबांदी"},
			61: {"en": "Slight rain", "hi": "हल्की बारिश"},
			63: {"en": "Moderate rain", "hi": "मध्यम बारिश"},
			65: {"en": "Heavy rain", "hi": "भारी बारिश"},
			71: {"en": "Slight snow fall", "hi": "हल्की बर्फबारी"},
			73: {"en": "Moderate snow fall", "hi": "मध्यम बर्फबारी"},
			75: {"en": "Heavy snow fall", "hi": "भारी बर्फबारी"},
			80: {"en": "Slight rain showers", "hi": "हल्की बारिश की बौछारें"},
			81: {"en": "Moderate rain showers", "hi": "मध्यम बारिश की बौछारें"},
			82: {"en": "Violent rain showers", "hi": "भयंकर बारिश की बौछारें"},
			95: {"en": "Thunderstorm", "hi": "आंधी-तूफान"},
			96: {"en": "Thunderstorm with light hail", "hi": "हल्की ओलावृष्टि के साथ तूफान"},
			99: {"en": "Thunderstorm with heavy hail", "hi": "भारी ओलावृष्टि के साथ तूफान"}
		}
		
		self.metric_names = {
			"temperature_2m": {"en": "Temperature", "hi": "तापमान"},
			"relative_humidity_2m": {"en": "Humidity", "hi": "हवा में नमी"},
			"apparent_temperature": {"en": "Feels Like", "hi": "महसूस होने वाला तापमान"},
			"precipitation": {"en": "Precipitation", "hi": "वर्षा"},
			"rain": {"en": "Rain", "hi": "बारिश"},
			"showers": {"en": "Showers", "hi": "बौछारें"},
			"snowfall": {"en": "Snowfall", "hi": "बर्फबारी"},
			"cloud_cover": {"en": "Cloud Cover", "hi": "बादलों का आवरण"},
			"pressure_msl": {"en": "Sea Level Pressure", "hi": "समुद्र तल का दबाव"},
			"surface_pressure": {"en": "Surface Pressure", "hi": "सतही वायुदाब"},
			"wind_speed_10m": {"en": "Wind Speed", "hi": "हवा की गति"},
			"wind_direction_10m": {"en": "Wind Direction", "hi": "हवा की दिशा"},
			"wind_gusts_10m": {"en": "Wind Gusts", "hi": "हवा के झोंके"},
			"is_day": {"en": "Time of Day", "hi": "दिन का समय"},
			"sunrise": {"en": "Sunrise", "hi": "सूर्योदय"},
			"sunset": {"en": "Sunset", "hi": "सूर्यास्त"},
			"uv_index_max": {"en": "Max UV Index", "hi": "अधिकतम यूवी इंडेक्स"},
			"precipitation_probability_max": {"en": "Precipitation Probability", "hi": "बारिश की संभावना"}
		}

	def _load_config(self):
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						self.lang = data.get("weather_lang", "Hindi")
						self.default_city = data.get("weather_default_city", "")
			except:
				pass

	def _save_config(self):
		data = {}
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					loaded = json.load(f)
					if isinstance(loaded, dict):
						data = loaded
			except:
				pass
		data["weather_lang"] = self.lang
		data["weather_default_city"] = self.default_city
		try:
			with open(self.settings_path, "w", encoding="utf-8") as f:
				json.dump(data, f)
		except:
			pass

	def _get_location_by_name(self, city_name):
		try:
			headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
			safe_city = urllib.parse.quote(city_name)
			url = f"https://geocoding-api.open-meteo.com/v1/search?name={safe_city}&count=1&language=en&format=json"
			req = urllib.request.Request(url, headers=headers, method="GET")
			with urllib.request.urlopen(req, timeout=10) as response:
				data = json.loads(response.read().decode("utf-8"))
				if "results" in data and len(data["results"]) > 0:
					res = data["results"][0]
					return {
						"lat": res["latitude"],
						"lon": res["longitude"],
						"city": res.get("name", city_name),
						"region": res.get("admin1", "Unknown Region"),
						"country": res.get("country", "Unknown Country")
					}
		except:
			pass
		return None

	def _format_time(self, iso_time_str):
		try:
			dt = datetime.strptime(iso_time_str, "%Y-%m-%dT%H:%M")
			return dt.strftime("%I:%M %p")
		except:
			return iso_time_str

	def _get_wind_direction(self, degree):
		dirs_en = ["North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West", "North"]
		dirs_hi = ["उत्तर", "उत्तर-पूर्व", "पूर्व", "दक्षिण-पूर्व", "दक्षिण", "दक्षिण-पश्चिम", "पश्चिम", "उत्तर-पश्चिम", "उत्तर"]
		idx = int(round((degree % 360) / 45))
		l_key = "hi" if self.lang == "Hindi" else "en"
		return dirs_hi[idx] if l_key == "hi" else dirs_en[idx]

	def _get_weather_data(self, loc):
		try:
			headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
			url = f"https://api.open-meteo.com/v1/forecast?latitude={loc['lat']}&longitude={loc['lon']}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m&daily=sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto"
			req = urllib.request.Request(url, headers=headers, method="GET")
			
			with urllib.request.urlopen(req, timeout=15) as response:
				data = json.loads(response.read().decode("utf-8"))
				
				current = data.get("current", {})
				c_units = data.get("current_units", {})
				daily = data.get("daily", {})
				d_units = data.get("daily_units", {})
				
				l_key = "hi" if self.lang == "Hindi" else "en"
				report_lines = []
				
				if l_key == "hi":
					report_lines.append(f"{loc['city']}, {loc['region']}, {loc['country']} की मौसम रिपोर्ट:")
				else:
					report_lines.append(f"Weather report for {loc['city']}, {loc['region']}, {loc['country']}:")
				
				code = current.get("weather_code")
				if code is not None:
					cond = self.wmo_codes.get(code, {"en": "Unknown condition", "hi": "अज्ञात स्थिति"})[l_key]
					if l_key == "hi":
						report_lines.append(f"स्थिति: {cond}")
					else:
						report_lines.append(f"Condition: {cond}")
				
				for key, val in current.items():
					if key in ["time", "interval", "weather_code"]:
						continue
					
					metric_name = self.metric_names.get(key, {}).get(l_key, key.replace("_", " ").title())
					unit = c_units.get(key, "")
					
					if key == "is_day":
						val = "Day" if val == 1 else "Night"
						if l_key == "hi":
							val = "दिन" if val == "Day" else "रात"
						unit = ""
					elif key == "wind_direction_10m":
						val = self._get_wind_direction(val)
						unit = ""
						
					report_lines.append(f"{metric_name}: {val} {unit}".strip())
				
				if daily:
					for key, val_list in daily.items():
						if key in ["time"]:
							continue
						
						val = val_list[0] if val_list and len(val_list) > 0 else "N/A"
						metric_name = self.metric_names.get(key, {}).get(l_key, key.replace("_", " ").title())
						unit = d_units.get(key, "")
						
						if key in ["sunrise", "sunset"] and val != "N/A":
							val = self._format_time(val)
							unit = ""
							
						report_lines.append(f"{metric_name}: {val} {unit}".strip())
				
				return ". ".join(report_lines)
		except Exception as e:
			return None

	def check_default_weather(self, is_shortcut=False):
		if not self.default_city:
			tones.beep(400, 150)
			wx.CallAfter(ui.message, "No default city set. Please set your city in the ATL Smart Weather menu.")
			return

		def worker():
			if is_shortcut:
				tones.beep(800, 100)
				wx.CallAfter(ui.message, "Checking weather securely, please wait...")
			
			loc = self._get_location_by_name(self.default_city)
			if not loc:
				tones.beep(400, 150)
				wx.CallAfter(ui.message, f"Could not find location data for your default city: {self.default_city}.")
				return
				
			report = self._get_weather_data(loc)
			if report:
				tones.beep(1000, 150)
				wx.CallAfter(ui.message, report)
			else:
				tones.beep(400, 150)
				wx.CallAfter(ui.message, "Failed to retrieve weather data from the server.")
		
		self.telemetry.track("Weather Assistant - Default Location Check")
		threading.Thread(target=worker, daemon=True).start()

	def search_weather(self):
		with wx.TextEntryDialog(None, "Enter city name to check weather:", "Search Weather") as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				city = dlg.GetValue().strip()
				if city:
					def worker():
						tones.beep(800, 100)
						wx.CallAfter(ui.message, "Checking weather securely, please wait...")
						loc = self._get_location_by_name(city)
						if not loc:
							tones.beep(400, 150)
							wx.CallAfter(ui.message, f"Could not find location data for {city}.")
							return
						report = self._get_weather_data(loc)
						if report:
							tones.beep(1000, 150)
							wx.CallAfter(ui.message, report)
						else:
							tones.beep(400, 150)
							wx.CallAfter(ui.message, "Failed to retrieve weather data from the server.")
					
					self.telemetry.track("Weather Assistant - City Search")
					threading.Thread(target=worker, daemon=True).start()

	def manage_default_city(self):
		if self.default_city:
			opts = [f"Change Default City (Current: {self.default_city})", "Delete Default City"]
			with wx.SingleChoiceDialog(None, "Manage your default city:", "Default City Settings", opts) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					sel = dlg.GetSelection()
					if sel == 0:
						self._set_default_city_dialog()
					elif sel == 1:
						self.default_city = ""
						self._save_config()
						tones.beep(500, 100)
						wx.MessageBox("Default city removed successfully.", "Success", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
		else:
			self._set_default_city_dialog()

	def _set_default_city_dialog(self):
		with wx.TextEntryDialog(None, "Enter your default city name:", "Set Default City", self.default_city) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				city = dlg.GetValue().strip()
				if city:
					self.default_city = city
					self._save_config()
					tones.beep(600, 100)
					wx.MessageBox(f"Default city successfully set to {city}.", "Success", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)

	def change_language(self):
		opts = ["English", "Hindi"]
		with wx.SingleChoiceDialog(None, "Select your preferred language for weather reports:", "Language Settings", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				self.lang = opts[sel]
				self._save_config()
				tones.beep(600, 100)
				wx.MessageBox(f"Language successfully changed to {self.lang}.", "Success", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)

	def open_menu(self):
		opts = [
			"1. Check Weather for Default City",
			"2. Search Weather for Any City",
			"3. Manage Default City",
			"4. Change Voice Language (English / Hindi)"
		]
		with wx.SingleChoiceDialog(None, "Select ATL Smart Weather Action:", "ATL Smart Weather Assistant", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					self.check_default_weather(is_shortcut=False)
				elif sel == 1:
					wx.CallAfter(self.search_weather)
				elif sel == 2:
					wx.CallAfter(self.manage_default_city)
				elif sel == 3:
					wx.CallAfter(self.change_language)