import os
import json
import urllib.parse
import webbrowser
import wx
import ui
import tones
import api
from . import telemetry_manager

class SmartSearchDialog(wx.Dialog):
	def __init__(self, parent, history, default_engine):
		super().__init__(parent, title="ATL Smart Search Hub V2.0", size=(550, 250))
		self.history = history
		
		sz = wx.BoxSizer(wx.VERTICAL)
		
		self.engines = ["Google", "YouTube", "Wikipedia", "Amazon", "Stack Overflow", "GitHub", "Bing", "DuckDuckGo", "Reddit", "Twitter"]
		
		lbl1 = wx.StaticText(self, label="Search Query or URL (Use prefixes like yt:, w:, a:):")
		sz.Add(lbl1, 0, wx.ALL, 5)
		
		self.query_cb = wx.ComboBox(self, choices=self.history, style=wx.CB_DROPDOWN | wx.TE_PROCESS_ENTER)
		sz.Add(self.query_cb, 0, wx.EXPAND | wx.ALL, 5)
		
		lbl2 = wx.StaticText(self, label="Select Default Engine:")
		sz.Add(lbl2, 0, wx.ALL, 5)
		
		self.engine_choice = wx.Choice(self, choices=self.engines)
		if default_engine in self.engines:
			self.engine_choice.SetSelection(self.engines.index(default_engine))
		else:
			self.engine_choice.SetSelection(0)
		sz.Add(self.engine_choice, 0, wx.EXPAND | wx.ALL, 5)
		
		btn_sz = wx.BoxSizer(wx.HORIZONTAL)
		self.btn_search = wx.Button(self, wx.ID_OK, label="Search")
		self.btn_cancel = wx.Button(self, wx.ID_CANCEL, label="Cancel")
		self.btn_clear = wx.Button(self, label="Clear History")
		
		self.btn_search.SetDefault()
		self.query_cb.Bind(wx.EVT_TEXT_ENTER, self.on_enter)
		self.btn_clear.Bind(wx.EVT_BUTTON, self.on_clear)
		
		btn_sz.Add(self.btn_search, 0, wx.ALL, 5)
		btn_sz.Add(self.btn_cancel, 0, wx.ALL, 5)
		btn_sz.Add(self.btn_clear, 0, wx.ALL, 5)
		
		sz.Add(btn_sz, 0, wx.CENTER | wx.ALL, 5)
		self.SetSizer(sz)
		self.CenterOnScreen()
		
		self._check_clipboard()

	def on_enter(self, evt):
		self.EndModal(wx.ID_OK)
		
	def on_clear(self, evt):
		self.query_cb.Clear()
		self.history.clear()
		tones.beep(500, 100)
		ui.message("Search history cleared.")
		self.query_cb.SetFocus()

	def _check_clipboard(self):
		try:
			clip_text = api.getClipData()
			if clip_text and isinstance(clip_text, str) and len(clip_text) < 200:
				if not clip_text.isspace():
					self.query_cb.SetValue(clip_text.strip())
		except:
			pass

	def get_query(self):
		return self.query_cb.GetValue().strip()

	def get_engine(self):
		return self.engines[self.engine_choice.GetSelection()]

class SearchManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.settings_path = os.path.join(os.path.dirname(__file__), "atl_master_settings.json")
		self.prefixes = {
			"g:": "Google",
			"yt:": "YouTube",
			"w:": "Wikipedia",
			"a:": "Amazon",
			"so:": "Stack Overflow",
			"gh:": "GitHub",
			"b:": "Bing",
			"ddg:": "DuckDuckGo",
			"r:": "Reddit",
			"t:": "Twitter"
		}
		self.urls = {
			"Google": "https://www.google.com/search?q={}",
			"YouTube": "https://www.youtube.com/results?search_query={}",
			"Wikipedia": "https://en.wikipedia.org/wiki/Special:Search?search={}",
			"Amazon": "https://www.amazon.in/s?k={}",
			"Stack Overflow": "https://stackoverflow.com/search?q={}",
			"GitHub": "https://github.com/search?q={}",
			"Bing": "https://www.bing.com/search?q={}",
			"DuckDuckGo": "https://duckduckgo.com/?q={}",
			"Reddit": "https://www.reddit.com/search/?q={}",
			"Twitter": "https://twitter.com/search?q={}"
		}

	def _load_settings(self):
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("search_manager", {"history": [], "last_engine": "Google"})
			except:
				pass
		return {"history": [], "last_engine": "Google"}

	def _save_settings(self, sm_data):
		data = {}
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					loaded = json.load(f)
					if isinstance(loaded, dict):
						data = loaded
			except:
				pass
		data["search_manager"] = sm_data
		try:
			with open(self.settings_path, "w", encoding="utf-8") as f:
				json.dump(data, f)
		except:
			pass

	def open_menu(self):
		tones.beep(850, 50)
		config = self._load_settings()
		history = config.get("history", [])
		last_engine = config.get("last_engine", "Google")

		dlg = SmartSearchDialog(None, history, last_engine)
		if dlg.ShowModal() == wx.ID_OK:
			raw_query = dlg.get_query()
			engine = dlg.get_engine()
			
			if not raw_query:
				tones.beep(300, 100)
				ui.message("Empty input. Search canceled.")
				dlg.Destroy()
				return
				
			if len(raw_query) > 500:
				tones.beep(300, 100)
				ui.message("Search text is too long. Max 500 characters allowed.")
				dlg.Destroy()
				return

			new_history = dlg.history
			if raw_query in new_history:
				new_history.remove(raw_query)
			new_history.insert(0, raw_query)
			if len(new_history) > 10:
				new_history = new_history[:10]

			config["history"] = new_history
			config["last_engine"] = engine
			self._save_settings(config)

			tones.beep(950, 50)
			
			if "." in raw_query and " " not in raw_query and not any(raw_query.lower().startswith(p) for p in self.prefixes):
				ui.message("Opening direct link")
				if not raw_query.startswith(("http://", "https://")):
					raw_query = "https://" + raw_query
				self.telemetry.track("Search Hub - Direct URL Opened")
				webbrowser.open(raw_query)
				dlg.Destroy()
				return

			for pfx, eng in self.prefixes.items():
				if raw_query.lower().startswith(pfx):
					engine = eng
					raw_query = raw_query[len(pfx):].strip()
					break

			if not raw_query:
				tones.beep(300, 100)
				ui.message("Empty query after prefix.")
				dlg.Destroy()
				return

			ui.message(f"Searching on {engine}")
			self.telemetry.track(f"Search Hub - {engine} Search")
			encoded_query = urllib.parse.quote(raw_query)
			final_url = self.urls.get(engine, self.urls["Google"]).format(encoded_query)
			webbrowser.open(final_url)
		else:
			tones.beep(400, 50)
			ui.message("Search Canceled")
		
		dlg.Destroy()