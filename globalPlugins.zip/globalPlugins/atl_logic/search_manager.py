import wx
import ui
import tones
import webbrowser
from . import telemetry_manager

class SearchManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()

	def open_menu(self):
		tones.beep(850, 50)
		with wx.TextEntryDialog(None, "Enter text or URL (Max 500 chars):", "Google Quick Search") as dialog:
			if dialog.ShowModal() == wx.ID_OK:
				query = dialog.GetValue().strip()
				if not query:
					tones.beep(300, 100)
					ui.message("Empty input. Please type something to search.")
					return
				if len(query) > 500:
					tones.beep(300, 100)
					ui.message("Search text is too long. Max 500 characters allowed.")
					return
				tones.beep(950, 50)
				if "." in query and " " not in query:
					ui.message("Opening link")
					if not query.startswith(("http://", "https://")):
						query = "https://" + query
					self.telemetry.track("Google Quick Search - Link Opened")
					webbrowser.open(query)
				else:
					ui.message("Searching on Google")
					self.telemetry.track("Google Quick Search - Web Search")
					webbrowser.open(f"https://www.google.com/search?q={query}")
			else:
				tones.beep(400, 50)
				ui.message("Search Canceled")