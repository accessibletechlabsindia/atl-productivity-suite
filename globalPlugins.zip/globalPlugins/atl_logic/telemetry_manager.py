import os
import json
import urllib.request
import urllib.parse
import threading
import wx

class TelemetryManager:
	def __init__(self):
		self.version = "v1.4"
		self.url = "https://docs.google.com/forms/d/e/1FAIpQLSevmFOLfrNqqnAoosxPprrJMi4RamnmuHOC1TN_FGK2wtgGUA/formResponse"
		self.local_dir = os.path.join(os.environ.get('LOCALAPPDATA', ''), "ATL_Productivity_Suite")
		self.data_dir = os.path.join(self.local_dir, "data")
		self.settings_file = os.path.join(self.local_dir, "telemetry_settings.json")
		self.log_file = os.path.join(self.data_dir, "pending_sync.log")
		if not os.path.exists(self.data_dir):
			try:
				os.makedirs(self.data_dir)
			except:
				pass

	def check_and_prompt_consent(self):
		if os.path.exists(self.settings_file):
			return
		def show_dialog():
			title = "Help Us Improve ATL Productivity Suite"
			msg = "To provide better support and prioritize the features you love, would you like to share anonymous usage statistics with us?\n\nWe deeply value your privacy:\n- NO personal data (names, files, or locations) is ever recorded.\n- We only track which features are used to help us improve the tool for the community.\n- This data is sent securely to our encrypted database.\n\nYour support helps us keep the ATL Suite fast and professional. May we enable this feature?"
			dlg = wx.MessageDialog(None, msg, title, wx.YES_NO | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
			res = dlg.ShowModal()
			dlg.Destroy()
			opt_in = (res == wx.ID_YES)
			try:
				with open(self.settings_file, "w", encoding="utf-8") as f:
					json.dump({"opt_in": opt_in}, f)
			except:
				pass
			if opt_in:
				self.track("ATL Suite - New Installation")
		wx.CallAfter(show_dialog)

	def is_opted_in(self):
		if not os.path.exists(self.settings_file):
			return False
		try:
			with open(self.settings_file, "r", encoding="utf-8") as f:
				data = json.load(f)
				return data.get("opt_in", False)
		except:
			return False

	def track(self, feature_name):
		if not self.is_opted_in():
			return
		threading.Thread(target=self._process_tracking, args=(feature_name,), daemon=True).start()

	def _process_tracking(self, feature_name):
		self._sync_offline()
		success = self._send_data(feature_name)
		if not success:
			self._save_offline(feature_name)

	def _send_data(self, feature_name):
		is_new_install = (feature_name == "ATL Suite - New Installation")
		feat_val = "-" if is_new_install else feature_name
		install_val = "New Install" if is_new_install else "-"
		data = {
			"entry.1353490209": feat_val,
			"entry.1465863099": self.version,
			"entry.217485786": install_val
		}
		encoded_data = urllib.parse.urlencode(data).encode('utf-8')
		req = urllib.request.Request(self.url, data=encoded_data)
		try:
			with urllib.request.urlopen(req, timeout=5) as response:
				return response.getcode() == 200
		except:
			return False

	def _save_offline(self, feature_name):
		try:
			with open(self.log_file, "a", encoding="utf-8") as f:
				f.write(feature_name + "\n")
		except:
			pass

	def _sync_offline(self):
		if not os.path.exists(self.log_file):
			return
		try:
			with open(self.log_file, "r", encoding="utf-8") as f:
				lines = f.readlines()
		except:
			return
		if not lines:
			return
		remaining = []
		for line in lines:
			feat = line.strip()
			if feat:
				if not self._send_data(feat):
					remaining.append(feat)
		try:
			if remaining:
				with open(self.log_file, "w", encoding="utf-8") as f:
					for r in remaining:
						f.write(r + "\n")
			else:
				os.remove(self.log_file)
		except:
			pass