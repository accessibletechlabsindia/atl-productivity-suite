import os
import ctypes
import time
import subprocess
import threading
import wx
import ui
import tones
import api
from . import telemetry_manager

class LoadingDialog(wx.Dialog):
	def __init__(self, parent, title, message):
		super().__init__(parent, title=title, size=(400, 150), style=wx.CAPTION | wx.STAY_ON_TOP)
		sz = wx.BoxSizer(wx.VERTICAL)
		self.lbl = wx.StaticText(self, label=message)
		font = self.lbl.GetFont()
		font.SetWeight(wx.FONTWEIGHT_BOLD)
		self.lbl.SetFont(font)
		sz.Add(self.lbl, 1, wx.ALL | wx.ALIGN_CENTER | wx.ALIGN_CENTER_VERTICAL, 20)
		self.SetSizer(sz)
		self.CenterOnScreen()

class ResultDialog(wx.Dialog):
	def __init__(self, parent, title, info):
		super().__init__(parent, title="ATL Enterprise System Dashboard", size=(650, 550), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER | wx.MAXIMIZE_BOX | wx.STAY_ON_TOP)
		sz = wx.BoxSizer(wx.VERTICAL)
		lbl = wx.StaticText(self, label=title)
		font = lbl.GetFont()
		font.SetWeight(wx.FONTWEIGHT_BOLD)
		lbl.SetFont(font)
		sz.Add(lbl, 0, wx.ALL | wx.ALIGN_CENTER, 10)
		self.tc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_RICH2)
		self.tc.SetValue(info)
		sz.Add(self.tc, 1, wx.EXPAND | wx.LEFT | wx.RIGHT, 10)
		bsz = wx.BoxSizer(wx.HORIZONTAL)
		cb = wx.Button(self, label="Copy Full Report")
		cb.Bind(wx.EVT_BUTTON, self.on_copy)
		clb = wx.Button(self, wx.ID_CANCEL, label="Close Dashboard")
		bsz.Add(cb, 0, wx.ALL, 10)
		bsz.Add(clb, 0, wx.ALL, 10)
		sz.Add(bsz, 0, wx.CENTER, 5)
		self.SetSizer(sz)
		self.info = info

	def on_copy(self, evt):
		if api.copyToClip(self.info):
			tones.beep(600, 50)
			tones.beep(800, 80)
			ui.message("Complete system report copied to clipboard.")

class SystemHealthManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.temp_dir = os.environ.get('TEMP')
		self.ps1_path = os.path.join(self.temp_dir, "atl_health_scan_v2.ps1")
		self.out_path = os.path.join(self.temp_dir, "atl_health_out_v2.txt")
		self.done_path = os.path.join(self.temp_dir, "atl_health_done_v2.txt")
		self.loading_dlg = None

	def open_menu(self):
		tones.beep(800, 50)
		msg = (
			"Do you want to run an Advanced Deep Health Scan?\n\n"
			"Selecting 'Yes' will extract deep telemetry including System Stability (Reliability Index), "
			"BSOD Crash Logs, Battery Wear, and Disk Predictive Failure. This requires Administrator privileges.\n\n"
			"Selecting 'No' will run a Standard Scan."
		)
		dlg = wx.MessageDialog(None, msg, "ATL Enterprise System Scanner", wx.YES_NO | wx.CANCEL | wx.ICON_QUESTION | wx.STAY_ON_TOP)
		res = dlg.ShowModal()
		dlg.Destroy()
		if res == wx.ID_CANCEL:
			return
		
		is_admin = (res == wx.ID_YES)
		self.telemetry.track("System Health - Full Deep Scan")
		threading.Thread(target=self._run_scan, args=(is_admin,), daemon=True).start()

	def _build_ps_script(self):
		script = f"""$ErrorActionPreference = 'SilentlyContinue'
$out = "{self.out_path}"
$done = "{self.done_path}"
$r = ""

$r += "--- [ SYSTEM & OS ] ---`r`n"
$os = Get-CimInstance Win32_OperatingSystem
$r += "OS Name: " + $os.Caption + "`r`n"
$r += "Version: " + $os.Version + " (Build " + $os.BuildNumber + ")`r`n"
$r += "Architecture: " + $os.OSArchitecture + "`r`n"
$r += "Install Date: " + $os.InstallDate + "`r`n"
$r += "Last Boot Time: " + $os.LastBootUpTime + "`r`n"
$bootEvent = Get-WinEvent -FilterHashtable @{{LogName="Microsoft-Windows-Diagnostics-Performance/Operational"; Id=100}} -MaxEvents 1
if ($bootEvent) {{
	$bootXml = [xml]$bootEvent.ToXml()
	$bootTimeMs = $bootXml.Event.EventData.Data | Where-Object {{ $_.Name -eq 'BootTime' }} | Select-Object -ExpandProperty '#text'
	if ($bootTimeMs) {{
		$bootTimeSec = [math]::Round([int]$bootTimeMs / 1000, 1)
		$r += "Actual Boot Duration: " + $bootTimeSec + " seconds`r`n"
	}}
}}
$r += "PC Name: " + $env:COMPUTERNAME + "`r`n"
$r += "Current User: " + $env:USERNAME + "`r`n`r`n"

$r += "--- [ SYSTEM STABILITY & CRASH ANALYSIS ] ---`r`n"
$stab = Get-CimInstance Win32_ReliabilityStabilityMetrics | Measure-Object -Average -Property systemStabilityIndex
if ($stab.Average) {{
	$r += "Overall Reliability Score: " + [math]::Round($stab.Average, 2) + " / 10`r`n"
}} else {{
	$r += "Overall Reliability Score: Data currently compiling.`r`n"
}}
$bsods = Get-WinEvent -FilterHashtable @{{LogName='System'; Id=1001; StartTime=(Get-Date).AddDays(-7)}} -MaxEvents 3
if ($bsods) {{
	$r += "CRITICAL: Blue Screen (BSOD) events detected in the last 7 days:`r`n"
	foreach ($b in $bsods) {{
		$r += " - Crash Date: " + $b.TimeCreated + "`r`n"
		$r += "   Details: " + ($b.Message -replace "`r`n", " ") + "`r`n"
	}}
}} else {{
	$r += "System Stability: 100% Stable. No BSOD crashes detected in the last 7 days.`r`n"
}}
$r += "`r`n"

$r += "--- [ PROCESSOR (CPU) ] ---`r`n"
$cpu = Get-CimInstance Win32_Processor
$r += "Model: " + $cpu.Name + "`r`n"
$r += "Cores: " + $cpu.NumberOfCores + " / Threads: " + $cpu.NumberOfLogicalProcessors + "`r`n"
$r += "Base Speed: " + $cpu.MaxClockSpeed + " MHz`r`n"
$r += "Current Load: " + $cpu.LoadPercentage + " %`r`n"
$r += "Virtualization Enabled: " + $cpu.VirtualizationFirmwareEnabled + "`r`n`r`n"

$r += "--- [ MEMORY (RAM) ] ---`r`n"
$r += "Total RAM: " + [math]::Round($os.TotalVisibleMemorySize/1MB, 2) + " GB`r`n"
$r += "Free RAM: " + [math]::Round($os.FreePhysicalMemory/1MB, 2) + " GB`r`n"
$mem = Get-CimInstance Win32_PhysicalMemory
$r += "Installed Modules: " + $mem.Count + "`r`n"
foreach ($m in $mem) {{
	$r += " - " + [math]::Round($m.Capacity/1GB, 2) + " GB @ " + $m.Speed + " MHz (" + $m.Manufacturer + ")`r`n"
}}
$r += "`r`n"

$r += "--- [ MOTHERBOARD & BIOS ] ---`r`n"
$mb = Get-CimInstance Win32_BaseBoard
$r += "Motherboard: " + $mb.Manufacturer + " " + $mb.Product + "`r`n"
$bios = Get-CimInstance Win32_BIOS
$r += "BIOS Version: " + $bios.Name + "`r`n"
$r += "Serial Number: " + $bios.SerialNumber + "`r`n"
$sb = Confirm-SecureBootUEFI
if ($sb -ne $null) {{ $r += "Secure Boot Status: " + $sb + "`r`n" }}
$r += "`r`n"

$r += "--- [ GRAPHICS (GPU) ] ---`r`n"
$gpu = Get-CimInstance Win32_VideoController
foreach ($g in $gpu) {{
	$r += "Model: " + $g.Name + "`r`n"
	$r += "VRAM: " + [math]::Round($g.AdapterRAM/1MB, 2) + " MB`r`n"
	$r += "Driver Version: " + $g.DriverVersion + "`r`n"
}}
$r += "`r`n"

$r += "--- [ STORAGE & S.M.A.R.T HEALTH ] ---`r`n"
$disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3"
foreach ($d in $disks) {{
	$r += "Drive " + $d.DeviceID + " (" + $d.FileSystem + "): " + [math]::Round($d.FreeSpace/1GB, 2) + " GB Free / " + [math]::Round($d.Size/1GB, 2) + " GB Total`r`n"
}}
$pdisks = Get-CimInstance -Namespace "Root\\Microsoft\\Windows\\Storage" -Class MSFT_PhysicalDisk
if ($pdisks) {{
	$r += "Deep Physical Drive Health:`r`n"
	foreach ($pd in $pdisks) {{
		$healthStr = if ($pd.HealthStatus -eq 0) {{ "Healthy (0)" }} elseif ($pd.HealthStatus -eq 1) {{ "Warning (1)" }} elseif ($pd.HealthStatus -eq 2) {{ "Unhealthy (2)" }} else {{ "Unknown" }}
		$predictStr = if ($pd.PredictFailure -eq $true) {{ "CRITICAL: Predictive Failure Detected!" }} else {{ "Safe (No Predictive Failure)" }}
		$r += " - " + $pd.FriendlyName + " | Type: " + $pd.MediaType + " | Status: " + $healthStr + " | S.M.A.R.T: " + $predictStr + "`r`n"
	}}
}}
$r += "`r`n"

$r += "--- [ BATTERY & POWER ] ---`r`n"
$bat = Get-CimInstance Win32_Battery
if ($bat) {{
	$r += "Status: " + $bat.BatteryStatus + " (1=Discharging, 2=AC Plugged)`r`n"
	$r += "Remaining Charge: " + $bat.EstimatedChargeRemaining + " %`r`n"
	$full = (Get-CimInstance -Namespace root\\wmi -Class BatteryFullChargedCapacity).FullChargedCapacity
	$design = (Get-CimInstance -Namespace root\\wmi -Class BatteryStaticData).DesignedCapacity
	if ($full -and $design) {{
		$r += "Design Capacity: " + $design + " mWh`r`n"
		$r += "Full Charged Capacity: " + $full + " mWh`r`n"
		$wear = 100 - [math]::Round(($full / $design) * 100, 2)
		if ($wear -lt 0) {{ $wear = 0 }}
		$r += "Battery Wear Level: " + $wear + " % Degradation`r`n"
	}}
}} else {{
	$r += "No Battery Detected (Desktop Environment).`r`n"
}}
$r += "`r`n"

$r += "--- [ NETWORK & CONNECTIVITY ] ---`r`n"
$net = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object {{ $_.IPEnabled -eq $True }}
foreach ($n in $net) {{
	$r += "Adapter: " + $n.Description + "`r`n"
	$r += "IPv4 Address: " + $n.IPAddress[0] + "`r`n"
	$r += "MAC Address: " + $n.MACAddress + "`r`n"
}}
$r += "`r`n"

$r += "--- [ STARTUP APPS (BOOT BOTTLENECKS) ] ---`r`n"
$startup = Get-CimInstance Win32_StartupCommand | Select-Object Name | Select-Object -First 15
if ($startup) {{
	$r += "Applications Loading at Boot:`r`n"
	foreach ($s in $startup) {{
		$r += " - " + $s.Name + "`r`n"
	}}
}}
$r += "`r`n"

$r += "--- [ SECURITY & ANTIVIRUS ] ---`r`n"
$av = Get-CimInstance -Namespace root\\SecurityCenter2 -Class AntiVirusProduct
if ($av) {{
	foreach ($a in $av) {{
		$r += "Antivirus Engine: " + $a.displayName + "`r`n"
	}}
}} else {{
	$r += "Antivirus Engine: Windows Defender (Default)`r`n"
}}

[IO.File]::WriteAllText($out, $r)
[IO.File]::WriteAllText($done, "DONE")
"""
		with open(self.ps1_path, "w", encoding="utf-8") as f:
			f.write(script)

	def _cleanup_temp_files(self):
		for path in [self.ps1_path, self.out_path, self.done_path]:
			if os.path.exists(path):
				try:
					os.remove(path)
				except:
					pass

	def _show_loading(self):
		self.loading_dlg = LoadingDialog(None, "ATL System Analyzer", "Compiling deep diagnostic report. Please wait...")
		self.loading_dlg.Show()
		tones.beep(800, 100)

	def _hide_loading(self):
		if self.loading_dlg:
			self.loading_dlg.Destroy()
			self.loading_dlg = None

	def _run_scan(self, is_admin):
		self._cleanup_temp_files()
		wx.CallAfter(self._show_loading)
		wx.CallAfter(ui.message, "Initiating diagnostic engine.")
		self._build_ps_script()

		if is_admin:
			cmd = f"-ExecutionPolicy Bypass -WindowStyle Hidden -File \"{self.ps1_path}\""
			ctypes.windll.shell32.ShellExecuteW(None, "runas", "powershell.exe", cmd, None, 0)
		else:
			subprocess.run(["powershell.exe", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", self.ps1_path], creationflags=0x08000000)

		timeout = 60
		start_time = time.time()
		while not os.path.exists(self.done_path):
			if time.time() - start_time > timeout:
				wx.CallAfter(self._hide_loading)
				wx.CallAfter(ui.message, "Diagnostics timed out or permission denied.")
				self._cleanup_temp_files()
				return
			time.sleep(1)

		try:
			with open(self.out_path, "r", encoding="utf-8") as f:
				report_data = f.read()
		except:
			report_data = "Error reading the generated report."

		self._cleanup_temp_files()
		wx.CallAfter(self._hide_loading)
		tones.beep(1000, 150)
		wx.CallAfter(ui.message, "Diagnostics complete.")
		
		title = "Deep Diagnostic Scan Report" if is_admin else "Standard Diagnostic Scan Report"
		wx.CallAfter(self._show_dialog, title, report_data.strip())

	def _show_dialog(self, title, data):
		dlg = ResultDialog(None, title, data)
		dlg.ShowModal()
		dlg.Destroy()