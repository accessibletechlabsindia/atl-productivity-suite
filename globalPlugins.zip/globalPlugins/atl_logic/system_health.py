import wx
import subprocess
import threading
import tones
import ui
import api
from datetime import datetime, timedelta

class ResultDialog(wx.Dialog):
	def __init__(self, parent, title, info):
		super().__init__(parent, title="ATL System Dashboard", size=(450, 300))
		sz = wx.BoxSizer(wx.VERTICAL)
		lbl = wx.StaticText(self, label=f"Detailed Report: {title}")
		sz.Add(lbl, 0, wx.ALL, 5)
		self.tc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY)
		self.tc.SetValue(info)
		sz.Add(self.tc, 1, wx.EXPAND | wx.ALL, 5)
		bsz = wx.BoxSizer(wx.HORIZONTAL)
		cb = wx.Button(self, label="Copy Information")
		cb.Bind(wx.EVT_BUTTON, self.on_copy)
		clb = wx.Button(self, wx.ID_CANCEL, label="Close")
		bsz.Add(cb, 0, wx.ALL, 5)
		bsz.Add(clb, 0, wx.ALL, 5)
		sz.Add(bsz, 0, wx.CENTER | wx.ALL, 5)
		self.SetSizer(sz)
		self.info = info

	def on_copy(self, evt):
		if api.copyToClip(self.info):
			tones.beep(600, 50)
			tones.beep(800, 80)
			ui.message("Information Copied to Clipboard")

class SystemHealthManager:
	def __init__(self):
		self.options = [
			"1. Battery Detailed Health",
			"2. Live RAM Usage",
			"3. CPU Load & Speed",
			"4. Storage Report (All Drives)",
			"5. Network Signal & SSID",
			"6. BIOS Version & Date",
			"7. Windows Edition & Build",
			"8. GPU & Graphics Details",
			"9. System Uptime",
			"10. Hardware Serial Number",
			"11. CPU Cores & Threads",
			"12. Motherboard Model",
			"13. Virtualization (VT-x) Status",
			"14. Display Driver Version",
			"15. System Locale & Timezone",
			"16. RAM Frequency (MHz)",
			"17. Network MAC Addresses",
			"18. Last Boot Timestamp",
			"19. PC Name & Username",
			"20. Security & Antivirus Status"
		]
		self.ps_scripts = [
			"Get-WmiObject Win32_Battery | ForEach-Object { 'Status: ' + $_.BatteryStatus + ', Remaining: ' + $_.EstimatedChargeRemaining + '%' }",
			"Get-WmiObject Win32_OperatingSystem | ForEach-Object { 'Total RAM: ' + [math]::Round($_.TotalVisibleMemorySize/1MB, 2) + ' GB, Free RAM: ' + [math]::Round($_.FreePhysicalMemory/1MB, 2) + ' GB' }",
			"Get-WmiObject Win32_Processor | Select-Object -ExpandProperty LoadPercentage | ForEach-Object { 'CPU Load: ' + $_ + '%' }",
			"Get-WmiObject Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { $_.DeviceID + ' ' + [math]::Round($_.FreeSpace/1GB, 2) + ' GB Free of ' + [math]::Round($_.Size/1GB, 2) + ' GB' } | Out-String",
			"netsh wlan show interfaces | Select-String -Pattern 'SSID|Signal|State' | Out-String",
			"Get-WmiObject Win32_BIOS | Select-Object -ExpandProperty Name",
			"(Get-WmiObject Win32_OperatingSystem).Caption + ' (Build: ' + (Get-WmiObject Win32_OperatingSystem).BuildNumber + ')'",
			"Get-WmiObject Win32_VideoController | Select-Object -ExpandProperty Name | Out-String",
			"(Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime | ForEach-Object { $_.Days.ToString() + ' Days, ' + $_.Hours.ToString() + ' Hours, ' + $_.Minutes.ToString() + ' Minutes' }",
			"Get-WmiObject Win32_BIOS | Select-Object -ExpandProperty SerialNumber",
			"Get-WmiObject Win32_Processor | ForEach-Object { 'Cores: ' + $_.NumberOfCores + ', Logical Processors: ' + $_.NumberOfLogicalProcessors } | Out-String",
			"Get-WmiObject Win32_BaseBoard | ForEach-Object { 'Manufacturer: ' + $_.Manufacturer + ', Product: ' + $_.Product }",
			"Get-WmiObject Win32_ComputerSystem | Select-Object -ExpandProperty VirtualizationFirmwareEnabled | ForEach-Object { 'Virtualization Enabled: ' + $_ }",
			"Get-WmiObject Win32_VideoController | Select-Object -ExpandProperty DriverVersion | Out-String",
			"(Get-WmiObject Win32_OperatingSystem).Locale + ' | ' + (Get-WmiObject Win32_TimeZone).Caption",
			"Get-WmiObject Win32_PhysicalMemory | Select-Object -First 1 -ExpandProperty Speed | ForEach-Object { 'RAM Speed: ' + $_ + ' MHz' }",
			"Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $True } | ForEach-Object { $_.Description + ' - MAC: ' + $_.MACAddress } | Out-String",
			"(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString()",
			"'PC Name: ' + $env:COMPUTERNAME + ', User: ' + $env:USERNAME",
			"Get-WmiObject -Namespace root\\SecurityCenter2 -Class AntiVirusProduct | Select-Object -ExpandProperty displayName | Out-String"
		]

	def open_menu(self):
		with wx.SingleChoiceDialog(None, "Select an option to scan:", "ATL System Dashboard", self.options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				idx = dlg.GetSelection()
				tones.beep(500, 100)
				ui.message(f"Scanning {self.options[idx]}")
				threading.Thread(target=self._fetch_and_show, args=(idx,), daemon=True).start()

	def _fetch_and_show(self, idx):
		script = self.ps_scripts[idx]
		try:
			res = subprocess.run(["powershell", "-Command", script], capture_output=True, text=True, creationflags=0x08000000, timeout=10)
			data = res.stdout.strip()
			if not data:
				data = "Information not available or not supported on this hardware."
		except:
			data = "Error retrieving information from system."
		tones.beep(1000, 150)
		ui.message("Scan Complete")
		wx.CallAfter(self._show_dialog, self.options[idx].split('. ', 1)[1], data)

	def _show_dialog(self, title, data):
		dlg = ResultDialog(None, title, data)
		dlg.ShowModal()
		dlg.Destroy()