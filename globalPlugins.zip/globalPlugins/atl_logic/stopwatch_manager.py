import wx
import time
from datetime import datetime
import ui
import tones
import api
from . import telemetry_manager

class ReportDialog(wx.Dialog):
	def __init__(self, parent, title, info):
		super().__init__(parent, title=title, size=(450, 300))
		sz = wx.BoxSizer(wx.VERTICAL)
		lbl = wx.StaticText(self, label="Detailed Session Report:")
		sz.Add(lbl, 0, wx.ALL, 5)
		self.tc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY)
		self.tc.SetValue(info)
		sz.Add(self.tc, 1, wx.EXPAND | wx.ALL, 5)
		bsz = wx.BoxSizer(wx.HORIZONTAL)
		cb = wx.Button(self, label="Copy Information")
		cb.Bind(wx.EVT_BUTTON, self.on_copy)
		clb = wx.Button(self, wx.ID_CANCEL, label="Close")
		bsz.Add(cb, 0, wx.ALL, 5)
		bsz.Add(clb, 0, wx.ALL, 5)
		sz.Add(bsz, 0, wx.CENTER | wx.ALL, 5)
		self.SetSizer(sz)
		self.info = info

	def on_copy(self, evt):
		if api.copyToClip(self.info):
			tones.beep(600, 50)
			tones.beep(800, 80)
			ui.message("Information Copied to Clipboard")

class StopwatchManager:
	def __init__(self):
		self.start_time = None
		self.start_dt = None
		self.telemetry = telemetry_manager.TelemetryManager()

	def open_menu(self):
		if self.start_time is None:
			options = ["Start Session", "Reset Stopwatch"]
		else:
			options = ["Stop and View Report", "Reset Stopwatch"]
			
		with wx.SingleChoiceDialog(None, "ATL Precision Stopwatch", "Stopwatch Menu", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				opt = options[sel]
				if opt == "Start Session":
					self.start_session()
				elif opt == "Stop and View Report":
					self.stop_session()
				elif opt == "Reset Stopwatch":
					self.reset_session()

	def start_session(self):
		self.telemetry.track("Stopwatch - Started")
		self.start_time = time.time()
		self.start_dt = datetime.now()
		tones.beep(800, 100)
		tones.beep(1200, 150)
		wx.CallAfter(wx.MessageBox, "Stopwatch successfully started. Focus on your task.", "ATL Precision Stopwatch", wx.OK | wx.ICON_INFORMATION)

	def stop_session(self):
		self.telemetry.track("Stopwatch - Stopped")
		end_time = time.time()
		end_dt = datetime.now()
		duration = end_time - self.start_time
		hours, rem = divmod(duration, 3600)
		minutes, seconds = divmod(rem, 60)
		
		hours = int(hours)
		minutes = int(minutes)
		seconds = int(seconds)
		
		if hours > 0:
			duration_str = f"{hours} Hours, {minutes} Minutes, and {seconds} Seconds"
		elif minutes > 0:
			duration_str = f"{minutes} Minutes and {seconds} Seconds"
		else:
			duration_str = f"{seconds} Seconds"
			
		report = (
			f"ATL Precision Report\n"
			f"--------------------\n"
			f"Started At: {self.start_dt.strftime('%I:%M:%S %p')}\n"
			f"Finished At: {end_dt.strftime('%I:%M:%S %p')}\n"
			f"Total Time: {duration_str}."
		)
		
		self.start_time = None
		self.start_dt = None
		tones.beep(1200, 100)
		tones.beep(800, 150)
		wx.CallAfter(self.show_report, report)

	def reset_session(self):
		self.telemetry.track("Stopwatch - Reset")
		self.start_time = None
		self.start_dt = None
		tones.beep(400, 150)
		wx.CallAfter(wx.MessageBox, "Stopwatch has been reset to zero.", "ATL Precision Stopwatch", wx.OK | wx.ICON_INFORMATION)

	def show_report(self, report):
		dlg = ReportDialog(None, "ATL Precision Stopwatch", report)
		dlg.ShowModal()
		dlg.Destroy()