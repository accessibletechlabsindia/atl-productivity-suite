import os
import json
import time
import threading
from datetime import datetime
import wx
import ui
import tones
import api
from . import telemetry_manager

class ReportDialog(wx.Dialog):
	def __init__(self, parent, title, info):
		super().__init__(parent, title=title, size=(450, 350))
		sz = wx.BoxSizer(wx.VERTICAL)
		lbl = wx.StaticText(self, label="Detailed Session Report:")
		sz.Add(lbl, 0, wx.ALL, 5)
		self.tc = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY)
		self.tc.SetValue(info)
		sz.Add(self.tc, 1, wx.EXPAND | wx.ALL, 5)
		bsz = wx.BoxSizer(wx.HORIZONTAL)
		cb = wx.Button(self, label="Copy Information")
		cb.Bind(wx.EVT_BUTTON, self.on_copy)
		clb = wx.Button(self, wx.ID_CANCEL, label="Close")
		bsz.Add(cb, 0, wx.ALL, 5)
		bsz.Add(clb, 0, wx.ALL, 5)
		sz.Add(bsz, 0, wx.CENTER | wx.ALL, 5)
		self.SetSizer(sz)
		self.info = info

	def on_copy(self, evt):
		if api.copyToClip(self.info):
			tones.beep(600, 50)
			tones.beep(800, 80)
			ui.message("Information Copied to Clipboard")

class StopwatchManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.settings_path = os.path.join(os.path.dirname(__file__), "atl_master_settings.json")
		self.mode = None
		self.is_paused = False
		self.start_time = 0
		self.elapsed_time = 0
		self.start_dt = None
		self.laps = []
		self.last_lap_total = 0
		self.pomo_event = threading.Event()

	def _load_history(self):
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("stopwatch_history", [])
			except:
				pass
		return []

	def _save_history(self, history_list):
		data = {}
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					loaded = json.load(f)
					if isinstance(loaded, dict):
						data = loaded
			except:
				pass
		data["stopwatch_history"] = history_list
		try:
			with open(self.settings_path, "w", encoding="utf-8") as f:
				json.dump(data, f)
		except:
			pass

	def _format_time(self, total_seconds):
		hours, rem = divmod(total_seconds, 3600)
		minutes, seconds = divmod(rem, 60)
		h, m, s = int(hours), int(minutes), int(seconds)
		if h > 0:
			return f"{h} Hours, {m} Minutes, {s} Seconds"
		elif m > 0:
			return f"{m} Minutes, {s} Seconds"
		return f"{s} Seconds"

	def open_menu(self):
		tones.beep(800, 50)
		if self.mode is None:
			opts = ["1. Standard Precision Stopwatch", "2. Pomodoro Focus Mode (25m Work / 5m Break)", "3. View Session History"]
			with wx.SingleChoiceDialog(None, "Select Stopwatch Mode:", "ATL Precision Stopwatch V2.0", opts) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					sel = dlg.GetSelection()
					if sel == 0: self._start_standard()
					elif sel == 1: self._start_pomodoro()
					elif sel == 2: self._view_history()
		elif self.mode == "standard":
			opts = []
			if not self.is_paused:
				opts = ["Pause Session", "Record Lap", "Stop and Save Report", "Cancel Session"]
			else:
				opts = ["Resume Session", "Stop and Save Report", "Cancel Session"]
			with wx.SingleChoiceDialog(None, "Standard Stopwatch is active:", "Stopwatch Controls", opts) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					opt = opts[dlg.GetSelection()]
					if opt == "Pause Session": self._pause_standard()
					elif opt == "Resume Session": self._resume_standard()
					elif opt == "Record Lap": self._record_lap()
					elif opt == "Stop and Save Report": self._stop_standard()
					elif opt == "Cancel Session": self._cancel_session()
		elif self.mode == "pomodoro":
			opts = ["Stop Pomodoro Session"]
			with wx.SingleChoiceDialog(None, "Pomodoro Mode is active:", "Pomodoro Controls", opts) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._stop_pomodoro()

	def _start_standard(self):
		self.telemetry.track("Stopwatch - Started")
		self.mode = "standard"
		self.is_paused = False
		self.elapsed_time = 0
		self.start_time = time.time()
		self.start_dt = datetime.now()
		self.laps = []
		self.last_lap_total = 0
		tones.beep(800, 100)
		tones.beep(1200, 150)
		wx.CallAfter(ui.message, "Stopwatch started.")

	def _pause_standard(self):
		self.elapsed_time += time.time() - self.start_time
		self.is_paused = True
		tones.beep(600, 100)
		wx.CallAfter(ui.message, "Stopwatch paused.")

	def _resume_standard(self):
		self.start_time = time.time()
		self.is_paused = False
		tones.beep(800, 100)
		wx.CallAfter(ui.message, "Stopwatch resumed.")

	def _record_lap(self):
		current_total = self.elapsed_time
		if not self.is_paused:
			current_total += time.time() - self.start_time
		lap_duration = current_total - self.last_lap_total
		self.laps.append(lap_duration)
		self.last_lap_total = current_total
		tones.beep(1000, 80)
		wx.CallAfter(ui.message, f"Lap {len(self.laps)} recorded: {self._format_time(lap_duration)}")

	def _stop_standard(self):
		self.telemetry.track("Stopwatch - Stopped")
		current_total = self.elapsed_time
		if not self.is_paused:
			current_total += time.time() - self.start_time
		end_dt = datetime.now()
		
		report_lines = [
			"ATL Precision Session Report",
			"-----------------------------",
			f"Date: {self.start_dt.strftime('%d-%m-%Y')}",
			f"Started: {self.start_dt.strftime('%I:%M:%S %p')}",
			f"Finished: {end_dt.strftime('%I:%M:%S %p')}",
			f"Total Duration: {self._format_time(current_total)}"
		]
		
		if self.laps:
			report_lines.append("")
			report_lines.append("Lap Details:")
			for i, l_dur in enumerate(self.laps, 1):
				report_lines.append(f"Lap {i}: {self._format_time(l_dur)}")
				
		full_report = "\n".join(report_lines)
		
		history = self._load_history()
		history.insert(0, {"date": self.start_dt.strftime('%Y-%m-%d %H:%M:%S'), "report": full_report})
		if len(history) > 20: history = history[:20]
		self._save_history(history)
		
		self.mode = None
		tones.beep(1200, 100)
		tones.beep(800, 150)
		dlg = ReportDialog(None, "Session Complete", full_report)
		dlg.ShowModal()
		dlg.Destroy()

	def _cancel_session(self):
		self.telemetry.track("Stopwatch - Reset")
		self.mode = None
		tones.beep(400, 150)
		wx.CallAfter(ui.message, "Session canceled.")

	def _start_pomodoro(self):
		self.telemetry.track("Stopwatch - Pomodoro Started")
		self.mode = "pomodoro"
		self.pomo_event.clear()
		threading.Thread(target=self._pomo_worker, daemon=True).start()
		tones.beep(800, 100)
		tones.beep(1200, 150)
		wx.CallAfter(ui.message, "Pomodoro Session Started. Please focus for 25 minutes.")

	def _stop_pomodoro(self):
		self.telemetry.track("Stopwatch - Pomodoro Stopped")
		self.mode = None
		self.pomo_event.set()
		tones.beep(400, 150)
		wx.CallAfter(ui.message, "Pomodoro Session Stopped.")

	def _pomo_worker(self):
		while not self.pomo_event.is_set():
			for _ in range(25 * 60):
				if self.pomo_event.is_set(): return
				time.sleep(1)
			
			tones.beep(1000, 200)
			tones.beep(1200, 200)
			wx.CallAfter(ui.message, "Focus session complete. Please take a 5-minute break.")
			
			for _ in range(5 * 60):
				if self.pomo_event.is_set(): return
				time.sleep(1)
				
			tones.beep(1200, 200)
			tones.beep(1000, 200)
			wx.CallAfter(ui.message, "Break over. Time to get back to work.")

	def _view_history(self):
		history = self._load_history()
		if not history:
			wx.CallAfter(ui.message, "No session history found.")
			return
			
		opts = ["Clear All History"] + [f"Session from {h['date']}" for h in history]
		with wx.SingleChoiceDialog(None, "Select a session to view or clear history:", "Session History", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					self._save_history([])
					tones.beep(500, 100)
					wx.CallAfter(ui.message, "Session history cleared.")
				else:
					report_text = history[sel - 1].get("report", "Error loading report.")
					d = ReportDialog(None, "Saved Session Report", report_text)
					d.ShowModal()
					d.Destroy()