import os
import json
import time
import threading
import ctypes
import wx
import ui
import tones
from datetime import datetime, timedelta
from .stopwatch_manager import StopwatchManager
from . import telemetry_manager

class AlarmManager:
	def __init__(self):
		self.addon_dir = os.path.dirname(__file__)
		self.sounds_dir = os.path.join(self.addon_dir, "Sounds")
		self.config_path = os.path.join(self.addon_dir, "alarms.json")
		self.alarms = self.load_alarms()
		self.stopwatch_mgr = StopwatchManager()
		self.mci = ctypes.windll.winmm.mciSendStringW
		self.telemetry = telemetry_manager.TelemetryManager()
		self.is_monitoring = True
		self.monitor_thread = threading.Thread(target=self._monitor_logic, daemon=True)
		self.monitor_thread.start()

	def load_alarms(self):
		if os.path.exists(self.config_path):
			try:
				with open(self.config_path, "r") as f:
					return json.load(f)
			except:
				return []
		return []

	def save_alarms(self):
		with open(self.config_path, "w") as f:
			json.dump(self.alarms, f)

	def _play_mp3(self, file_path, duration_str, stop_event, loop=True):
		if not os.path.exists(file_path): return
		dur_map = {"30 Seconds": 30, "1 Minute": 60, "2 Minutes": 120, "3 Minutes": 180, "4 Minutes": 240, "5 Minutes": 300}
		total_seconds = dur_map.get(duration_str, 60)
		alias = f"atl_{int(time.time() * 1000)}_{id(stop_event)}"
		self.mci(f'open "{file_path}" type mpegvideo alias {alias}', None, 0, 0)
		self.mci(f'play {alias} {"repeat" if loop else ""}', None, 0, 0)
		start_time = time.time()
		while time.time() - start_time < total_seconds and not stop_event.is_set():
			time.sleep(0.5)
		self.mci(f'stop {alias}', None, 0, 0)
		self.mci(f'close {alias}', None, 0, 0)

	def _monitor_logic(self):
		alert_fired = set()
		while self.is_monitoring:
			now = datetime.now()
			today_str = now.strftime("%Y-%m-%d")
			for i, alarm in enumerate(self.alarms):
				if alarm.get("snooze_until"):
					s_time = datetime.fromisoformat(alarm["snooze_until"])
					if now >= s_time:
						alarm["snooze_until"] = None
						self.trigger_alarm(alarm, i)
					continue
				a_h, a_m = int(alarm['hour']), int(alarm['minute'])
				alarm_dt = now.replace(hour=a_h, minute=a_m, second=0, microsecond=0)
				if alarm.get("use_alert"):
					alert_dt = alarm_dt - timedelta(minutes=1)
					if now >= alert_dt and now < alarm_dt and alarm_dt.isoformat() not in alert_fired:
						alert_path = os.path.join(self.sounds_dir, "alert.mp3")
						threading.Thread(target=self._play_mp3, args=(alert_path, "30 Seconds", threading.Event(), False), daemon=True).start()
						alert_fired.add(alarm_dt.isoformat())
				if now >= alarm_dt and now < alarm_dt + timedelta(seconds=30):
					last_t = alarm.get("last_triggered_date", "")
					should_fire = False
					rep = alarm.get("repeat", "Once")
					if last_t != today_str:
						if rep == "Once" or rep == "Daily":
							should_fire = True
						elif rep == "Weekly" and now.weekday() == alarm.get("weekday", now.weekday()):
							should_fire = True
						elif rep == "Monthly" and now.day == alarm.get("monthday", now.day):
							should_fire = True
					if should_fire:
						alarm["last_triggered_date"] = today_str
						self.save_alarms()
						self.trigger_alarm(alarm, i)
			if now.hour == 0 and now.minute == 0: alert_fired.clear()
			time.sleep(1)

	def trigger_alarm(self, alarm, index):
		stop_event = threading.Event()
		tone_path = alarm['path']
		if not os.path.isabs(tone_path):
			tone_path = os.path.join(self.sounds_dir, tone_path)
		threading.Thread(target=self._play_mp3, args=(tone_path, alarm.get("duration", "1 Minute"), stop_event, True), daemon=True).start()
		wx.CallAfter(self.show_ring_dialog, alarm, stop_event)

	def show_ring_dialog(self, alarm, stop_event):
		dlg = wx.Dialog(None, title="ATL Alarm Ringing", style=wx.STAY_ON_TOP | wx.CAPTION)
		sz = wx.BoxSizer(wx.VERTICAL)
		msg = wx.StaticText(dlg, label=f"Alarm: {alarm['label']}\nTime: {alarm['hour']}:{alarm['minute']}")
		sz.Add(msg, 0, wx.ALL | wx.CENTER, 20)
		btn_sz = wx.BoxSizer(wx.HORIZONTAL)
		stop_btn = wx.Button(dlg, label="Stop")
		snz_btn = wx.Button(dlg, label="Snooze")
		btn_sz.Add(stop_btn, 1, wx.ALL, 5)
		btn_sz.Add(snz_btn, 1, wx.ALL, 5)
		sz.Add(btn_sz, 0, wx.EXPAND | wx.ALL, 10)
		def on_stop(e):
			stop_event.set()
			if alarm.get("repeat") == "Once":
				if alarm in self.alarms:
					self.alarms.remove(alarm)
					self.save_alarms()
			dlg.EndModal(wx.ID_OK)
		def on_snz(e):
			stop_event.set()
			s_min = int(alarm.get("snooze_time", "5 Minutes").split()[0])
			alarm["snooze_until"] = (datetime.now() + timedelta(minutes=s_min)).isoformat()
			self.save_alarms()
			tones.beep(600, 100)
			wx.MessageBox(f"Alarm snoozed for {s_min} minutes.", "ATL Alarm Manager", wx.OK | wx.ICON_INFORMATION)
			dlg.EndModal(wx.ID_CANCEL)
		stop_btn.Bind(wx.EVT_BUTTON, on_stop)
		snz_btn.Bind(wx.EVT_BUTTON, on_snz)
		dlg.SetSizer(sz)
		dlg.Fit()
		dlg.Center()
		dlg.ShowModal()
		stop_event.set()
		dlg.Destroy()

	def open_menu(self):
		opts = ["Set New Alarm", "Manage Alarms", "ATL Precision Stopwatch"]
		with wx.SingleChoiceDialog(None, "ATL Alarm Manager Menu", "Main Menu", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					wx.CallAfter(self.set_alarm_dialog)
				elif sel == 1:
					wx.CallAfter(self.manage_alarms_dialog)
				elif sel == 2:
					wx.CallAfter(self.stopwatch_mgr.open_menu)

	def set_alarm_dialog(self, edit_idx=None):
		data = self.alarms[edit_idx] if edit_idx is not None else {}
		dlg = wx.Dialog(None, title="Setup Your Alarm")
		sz = wx.BoxSizer(wx.VERTICAL)
		sz.Add(wx.StaticText(dlg, label="Alarm Label (Write name for the alarm):"), 0, wx.ALL, 5)
		label_ctrl = wx.TextCtrl(dlg, value=data.get("label", "New Alarm"))
		sz.Add(label_ctrl, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Alarm Hour (00 to 23):"), 0, wx.ALL, 5)
		h_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(24)], style=wx.CB_READONLY)
		h_cb.SetValue(data.get("hour", "08"))
		sz.Add(h_cb, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Alarm Minute (00 to 59):"), 0, wx.ALL, 5)
		m_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(60)], style=wx.CB_READONLY)
		m_cb.SetValue(data.get("minute", "00"))
		sz.Add(m_cb, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Repeat Schedule:"), 0, wx.ALL, 5)
		rep_cb = wx.ComboBox(dlg, choices=["Once", "Daily", "Weekly", "Monthly"], style=wx.CB_READONLY)
		rep_cb.SetValue(data.get("repeat", "Daily"))
		sz.Add(rep_cb, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Ringing Duration:"), 0, wx.ALL, 5)
		dur_cb = wx.ComboBox(dlg, choices=["30 Seconds", "1 Minute", "2 Minutes", "3 Minutes", "4 Minutes", "5 Minutes"], style=wx.CB_READONLY)
		dur_cb.SetValue(data.get("duration", "1 Minute"))
		sz.Add(dur_cb, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Snooze Interval Time:"), 0, wx.ALL, 5)
		snz_opts = [f"{i} Minutes" for i in range(1, 31)]
		snz_cb = wx.ComboBox(dlg, choices=snz_opts, style=wx.CB_READONLY)
		snz_cb.SetValue(data.get("snooze_time", "5 Minutes"))
		sz.Add(snz_cb, 0, wx.EXPAND | wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Alarm Ringtone:"), 0, wx.ALL, 5)
		t_map = {"Xiaomi Remix": "xiaomi_original_remix.mp3", "Infinix": "infinix_ringtone.mp3", "Samsung S24": "samsung_s24_ultra.mp3", "Subhanallah": "subhanallah.mp3", "Custom...": "CUSTOM"}
		tone_cb = wx.ComboBox(dlg, choices=list(t_map.keys()), style=wx.CB_READONLY)
		tone_cb.SetValue("Xiaomi Remix")
		sz.Add(tone_cb, 0, wx.EXPAND | wx.ALL, 5)
		alert_chk = wx.CheckBox(dlg, label="Play warning alert 1 minute before alarm")
		alert_chk.SetValue(data.get("use_alert", False))
		sz.Add(alert_chk, 0, wx.ALL, 5)
		br_btn = wx.Button(dlg, label="Browse Custom MP3 File")
		br_btn.Disable()
		sz.Add(br_btn, 0, wx.ALL, 5)
		c_path = [data.get("path") if data.get("path") and os.path.isabs(data.get("path")) else None]
		def on_t_change(e):
			if tone_cb.GetValue() == "Custom...": br_btn.Enable()
			else: br_btn.Disable()
		def on_br(e):
			with wx.FileDialog(None, "Choose one MP3 file", wildcard="MP3 files (*.mp3)|*.mp3", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as f_dlg:
				if f_dlg.ShowModal() == wx.ID_OK:
					c_path[0] = f_dlg.GetPath()
					tones.beep(800, 50)
					ui.message("Custom tone selected")
		tone_cb.Bind(wx.EVT_COMBOBOX, on_t_change)
		br_btn.Bind(wx.EVT_BUTTON, on_br)
		if data.get("path") == "CUSTOM" or (data.get("path") and os.path.isabs(data.get("path"))):
			tone_cb.SetValue("Custom...")
			br_btn.Enable()
		btn_sz = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
		sz.Add(btn_sz, 0, wx.CENTER | wx.ALL, 10)
		dlg.SetSizer(sz)
		dlg.Fit()
		if dlg.ShowModal() == wx.ID_OK:
			sel_t = tone_cb.GetValue()
			final_p = c_path[0] if sel_t == "Custom..." else t_map[sel_t]
			new_a = {
				"hour": h_cb.GetValue(), "minute": m_cb.GetValue(),
				"label": label_ctrl.GetValue(), "repeat": rep_cb.GetValue(),
				"duration": dur_cb.GetValue(), "snooze_time": snz_cb.GetValue(),
				"path": final_p, "use_alert": alert_chk.GetValue(),
				"weekday": datetime.now().weekday(), "monthday": datetime.now().day,
				"last_triggered_date": ""
			}
			if edit_idx is not None: self.alarms[edit_idx] = new_a
			else: self.alarms.append(new_a)
			self.save_alarms()
			self.telemetry.track("Alarm Manager - Alarm Set")
			tones.beep(800, 100)
			tones.beep(1200, 150)
			wx.MessageBox("Alarm saved successfully. Your schedule has been updated.", "ATL Alarm Manager", wx.OK | wx.ICON_INFORMATION)
		dlg.Destroy()

	def manage_alarms_dialog(self):
		if not self.alarms:
			tones.beep(400, 100)
			wx.MessageBox("No scheduled alarms found. Please set a new alarm first.", "ATL Alarm Manager", wx.OK | wx.ICON_WARNING)
			return
		opts = [f"{a['hour']}:{a['minute']} - {a['label']} ({a['repeat']})" for a in self.alarms]
		with wx.SingleChoiceDialog(None, "Select Alarm to manage:", "Manage Alarms", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				idx = dlg.GetSelection()
				m_opts = ["Edit Alarm", "Delete Alarm"]
				with wx.SingleChoiceDialog(None, f"Options for {opts[idx]}:", "Alarm Options", m_opts) as m_dlg:
					if m_dlg.ShowModal() == wx.ID_OK:
						if m_dlg.GetSelection() == 0: wx.CallAfter(self.set_alarm_dialog, idx)
						else:
							self.alarms.pop(idx)
							self.save_alarms()
							self.telemetry.track("Alarm Manager - Alarm Deleted")
							tones.beep(500, 100)
							wx.MessageBox("Alarm deleted successfully.", "ATL Alarm Manager", wx.OK | wx.ICON_INFORMATION)