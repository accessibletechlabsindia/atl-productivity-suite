import wx
import webbrowser
import ui
import os
from . import telemetry_manager

class AboutManager:
	def __init__(self):
		self.developer_name = "Krishna Kumar"
		self.brand_name = "Accessible Tech Labs India"
		self.version = "1.4"
		self.website_url = "https://accessibletechlabsindia.github.io/"
		self.email_gmail = "kirshnakumar6644@gmail.com"
		self.email_outlook = "accessibletechlabsindia@outlook.com"
		self.youtube_url = "https://www.youtube.com/channel/UCMEfIGRzJdBMYqWVaUhEnFw"
		self.tutorial_url = "https://youtu.be/39MOUFFgb6M?si=yodeAJQ6JZJyGUrI"
		self.telegram_channel_url = "https://telegram.me/+9hXlRWT6SVVhMjY9"
		self.telegram_contact_url = "https://telegram.me/+919352815634"
		self.whatsapp_url = "https://wa.me/919352815634"
		self.telemetry = telemetry_manager.TelemetryManager()

	def get_about_details(self):
		content = f"""
ACCESSIBLE TECH LABS INDIA - MASTER TOOLSET
Version: {self.version}
Lead Developer: {self.developer_name}
------------------------------------------------------------

WELCOME TO ACCESSIBLE TECH LABS INDIA (ATL)
Accessible Tech Labs India is a pioneer initiative dedicated to bridging the gap between advanced technology and accessibility. Our mission is to empower visually impaired individuals by providing high-quality, efficient, and fully accessible software solutions that enhance productivity and simplify digital interactions.

ABOUT THIS ADDON (VERSION 1.4)
This is the flagship NVDA Global Plugin developed by ATL India. Designed as a comprehensive workstation assistant, it integrates 9 essential system utilities directly into your screen reader environment, bringing power-user tools to your fingertips. 

WATCH FULL VIDEO ADDON GUIDE STEP BY STEP:
{self.tutorial_url}

KEY FEATURES AND IN-DEPTH CAPABILITIES:

1. ATL SENTINEL SECURITY SCANNER:
An enterprise-grade, highly advanced security integration powered by the VirusTotal API. Visually impaired users often struggle with complex antivirus interfaces. This tool bridges that gap by allowing you to instantly scan any local file (up to 650 MB) or suspicious web URL directly through NVDA. It checks your target against more than 70 industry-leading security engines and provides a clean, accessible, and easy-to-read safety report, ensuring your system remains impenetrable.

2. SYSTEM HEALTH DASHBOARD:
Screen reader users frequently miss out on critical visual warnings regarding system overload or low battery. The System Health Dashboard solves this by offering real-time, highly accurate audio feedback on your computer's vital statistics. With a single command, you receive an instant diagnostic readout of your current CPU processing load, available Random Access Memory (RAM), and exact battery percentage, allowing you to optimize performance effortlessly.

3. ADVANCED SYSTEM CLEANER:
Windows operating systems naturally accumulate digital clutter over time, which can significantly slow down screen reader response times. Our Advanced System Cleaner is a robust, automated utility designed to maintain absolute system hygiene. With zero visual navigation required, it safely flushes out Windows temporary files, prefetch data, application junk, and browser caches from Google Chrome and Microsoft Edge, keeping your machine lightning-fast and highly responsive.

4. SMART QUICK LAUNCHER:
A revolutionary and highly customizable productivity hub built to accelerate your daily workflow. The Quick Launcher allows you to digitally map your most frequently used desktop applications, specific folder paths, or important web URLs to 10 dedicated numbered slots. Once configured, you can execute these targets instantly using dedicated keyboard shortcuts, entirely bypassing the Windows Desktop, Start Menu, or File Explorer navigation.

5. GOOGLE QUICK SEARCH:
Searching the web traditionally involves opening a browser, navigating to the address bar, typing a query, and waiting for the page to load. The Google Quick Search utility eliminates all these intermediate steps. Simply trigger the command from anywhere in your operating system, type your query into the accessible input dialog, and hit enter. The addon automatically launches your default browser and securely fetches the search results, saving you valuable time and keystrokes.

6. ALARM AND SCHEDULING MANAGER:
An integrated, highly accessible scheduling utility built to help you manage your time with absolute precision. Unlike standard Windows alarms which can be difficult to configure via screen readers, our Alarm Manager uses simplified, speech-optimized dialogs. It features high-fidelity, customized audio tones to ensure you never miss an important meeting, task, or deadline, acting as your personal digital timekeeper.

7. POWER MANAGER:
Managing your computer's power states has never been easier or more secure. The Power Manager module allows you to execute critical system actions such as Restart, Shutdown, and Sleep without ever needing to navigate the Windows Start Menu hierarchy. Designed with accessibility in mind, it provides immediate execution with clear audio confirmations, ensuring a safe and efficient power-down process.

8. ATL PRECISION STOPWATCH:
A flawlessly accurate, fully accessible stopwatch utility tailored for professionals and students alike. Whether you are tracking the time taken to write a piece of code, timing a mock examination, or simply monitoring a daily task, this tool provides seamless start, stop, and reading functionalities. It announces elapsed time clearly, making time-tracking entirely independent and hassle-free.

9. ATL MASTER MENU:
To ensure maximum convenience, we have centralized all the aforementioned utilities into one single, alphabetically sorted hub. The ATL Master Menu acts as the brain of the addon. If you ever forget a specific shortcut key, simply invoke the Master Command, and you will be presented with a clean, easily navigable list of all 9 tools, ready to be executed with a simple press of the Enter key.

------------------------------------------------------------
SUPPORT AND COMMUNITY:
Your feedback drives our innovation. We strongly encourage you to watch our comprehensive YouTube tutorials for a deeper understanding of the toolset. Furthermore, join our official Telegram channel and WhatsApp community to receive real-time updates, interact with fellow users, and obtain dedicated technical support directly from the developer.

© 2026 Accessible Tech Labs India. All Rights Reserved.
		"""
		return content

	def get_shortcuts_details(self):
		content = """
ACCESSIBLE TECH LABS INDIA - SHORTCUTS & GESTURES
------------------------------------------------------------

Every tool in the ATL Productivity Suite can be accessed either via its Direct Keyboard Shortcut or through the centralized ATL Master Menu.

MASTER COMMAND:
- Open ATL Master Menu: NVDA + Shift + M
  (From this menu, you can navigate up/down or press the corresponding number to launch any tool).

DIRECT TOOL SHORTCUTS (Quick Access):
- Alarm Manager: NVDA + Shift + A
- Power Manager: NVDA + Shift + P
- System Health Dashboard: NVDA + Shift + H
- System Cleaner: NVDA + Shift + C
- Google Quick Search: NVDA + Shift + G
- Quick Launcher Config Menu: NVDA + Shift + Q
- About ATL Suite & Help: NVDA + Shift + O

SMART QUICK LAUNCHER EXECUTION:
(Use these after configuring your items in the Quick Launcher Menu)
- Launch Slot 1: NVDA + Windows + 1
- Launch Slot 2: NVDA + Windows + 2
- Launch Slot 3: NVDA + Windows + 3
- Launch Slot 4: NVDA + Windows + 4
- Launch Slot 5: NVDA + Windows + 5
- Launch Slot 6: NVDA + Windows + 6
- Launch Slot 7: NVDA + Windows + 7
- Launch Slot 8: NVDA + Windows + 8
- Launch Slot 9: NVDA + Windows + 9
- Launch Slot 10: NVDA + Windows + 0

TOOLS AVAILABLE EXCLUSIVELY VIA MASTER MENU:
(Press NVDA + Shift + M, then select the tool)
- ATL Precision Stopwatch (Press 2)
- ATL Sentinel Security Scanner (Press 3)

Note: If a shortcut conflicts with another addon, you can easily change it by going to NVDA Menu -> Preferences -> Input Gestures, and finding the "ATL Productivity Suite" category.
		"""
		return content

	def open_menu(self):
		options = [
			"1. Read Full Addon Description (About)",
			"2. View All Shortcuts & Gestures",
			"3. Watch Full Video Addon Guide Step by Step",
			"4. Visit Official Website",
			"5. Subscribe to YouTube Channel",
			"6. Join Official Telegram Channel",
			"7. Contact Developer via Telegram",
			"8. Contact Developer via WhatsApp",
			"9. Contact Developer via Gmail",
			"10. Contact Developer via Outlook"
		]
		
		with wx.SingleChoiceDialog(None, "Select an Option:", "About ATL Master Toolset", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					self.telemetry.track("About ATL - Read Description")
					ui.browseableMessage(self.get_about_details(), title="About - Accessible Tech Labs India")
				elif sel == 1:
					self.telemetry.track("About ATL - Viewed Shortcuts")
					ui.browseableMessage(self.get_shortcuts_details(), title="Shortcuts - Accessible Tech Labs India")
				elif sel == 2:
					self.telemetry.track("About ATL - Watched Tutorial")
					webbrowser.open(self.tutorial_url)
					ui.message("Opening Video Tutorial...")
				elif sel == 3:
					self.telemetry.track("About ATL - Visited Website")
					webbrowser.open(self.website_url)
					ui.message("Opening Website...")
				elif sel == 4:
					self.telemetry.track("About ATL - Visited YouTube")
					webbrowser.open(self.youtube_url)
					ui.message("Opening YouTube Channel...")
				elif sel == 5:
					self.telemetry.track("About ATL - Joined Telegram Channel")
					webbrowser.open(self.telegram_channel_url)
					ui.message("Opening Telegram Channel...")
				elif sel == 6:
					self.telemetry.track("About ATL - Clicked Telegram Contact")
					webbrowser.open(self.telegram_contact_url)
					ui.message("Opening Telegram Chat...")
				elif sel == 7:
					self.telemetry.track("About ATL - Clicked WhatsApp")
					webbrowser.open(self.whatsapp_url)
					ui.message("Opening WhatsApp...")
				elif sel == 8:
					self.telemetry.track("About ATL - Clicked Gmail")
					webbrowser.open(f"mailto:{self.email_gmail}")
					ui.message("Preparing Gmail...")
				elif sel == 9:
					self.telemetry.track("About ATL - Clicked Outlook")
					webbrowser.open(f"mailto:{self.email_outlook}")
					ui.message("Preparing Outlook Email...")