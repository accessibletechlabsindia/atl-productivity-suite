import wx
import webbrowser
import ui
import os

class AboutManager:
    def __init__(self):
        self.developer_name = "Krishna Kumar"
        self.brand_name = "Accessible Tech Labs India"
        self.version = "1.0"
        self.website_url = "https://accessibletechlabsindia.github.io/"
        self.email = "kirshnakumar6644@gmail.com"
        self.youtube_url = "https://www.youtube.com/channel/UCMEfIGRzJdBMYqWVaUhEnFw"
        self.telegram_url = "https://t.me/+9hXlRWT6SVVhMjY9"

    def get_about_details(self):
        """Returns a comprehensive professional description of the addon."""
        content = f"""
ACCESSIBLE TECH LABS INDIA - MASTER TOOLSET
Version: {self.version}
Lead Developer: {self.developer_name}
------------------------------------------------------------

WELCOME TO ACCESSIBLE TECH LABS INDIA (ATL)
Accessible Tech Labs India is a pioneer initiative dedicated to bridging the gap between advanced technology and accessibility. Our mission is to empower visually impaired individuals by providing high-quality, efficient, and fully accessible software solutions that enhance productivity and simplify digital interactions.

ABOUT THIS ADDON
This is the flagship NVDA Global Plugin developed by ATL India. It is designed to be a comprehensive workstation assistant, integrating essential system utilities directly into your screen reader environment. This addon eliminates the need for complex navigation through Windows menus, bringing power-user tools to your fingertips.

KEY FEATURES AND CAPABILITIES:

1. SYSTEM HEALTH DASHBOARD:
Real-time monitoring of your system's vital statistics. This tool provides instant feedback on CPU usage, RAM availability, and battery status, ensuring your machine is always performing at its peak.

2. ADVANCED SYSTEM CLEANER:
A robust utility designed to maintain system hygiene. It targets Windows junk files, temporary directories, prefetch data, and browser caches (Chrome and Edge). By automating the cleanup process, it ensures your system remains fast and responsive without manual intervention.

3. SMART QUICK LAUNCHER:
A customizable productivity hub that allows you to map your most-used applications, folders, or web URLs to specific slots. With instant keyboard execution, your entire workflow is just one shortcut away.

4. ALARM AND POWER MANAGER:
Integrated scheduling and power control utilities. Manage your time with precision and execute system power actions (Restart, Shutdown, Sleep) with screen-reader-optimized dialogues.

5. ACCESSIBILITY COMMITMENT:
Every element of this addon is built with 'Accessibility First' logic. We utilize high-fidelity audio cues (Tones) and clear UI messages to provide a seamless experience for NVDA and TalkBack users.

OUR VISION:
At Accessible Tech Labs India, we believe that disability should never be a barrier to innovation. We are committed to developing audio-guided games, spatial audio workstations, and utility scripts that redefine what is possible in the world of assistive technology.

DEVELOPER PROFILE:
Krishna Kumar is a dedicated developer and the visionary behind Accessible Tech Labs India. With expertise in Python, AutoHotkey, and Web Audio APIs, Krishna focuses on creating software that is not just functional, but also inclusive by design.

SUPPORT AND COMMUNITY:
By using this addon, you are part of a growing community of users who value speed and accessibility. We encourage you to visit our YouTube channel for detailed tutorials and join our Telegram community for real-time updates and technical support.

THANK YOU:
Thank you for choosing Accessible Tech Labs India. Your support drives our innovation. We are committed to continuous improvement, and version 1.0 is just the beginning of our journey toward total digital inclusion.

© 2026 Accessible Tech Labs India. All Rights Reserved.
        """
        return content

    def open_menu(self):
        options = [
            "1. Read Full Addon Description (About)",
            "2. Visit Official Website",
            "3. Subscribe to YouTube Channel",
            "4. Join Telegram Channel",
            "5. Contact Developer via Email"
        ]
        
        with wx.SingleChoiceDialog(None, "Select an Option:", "About ATL Master Toolset", options) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                sel = dlg.GetSelection()
                if sel == 0:
                    ui.browseableMessage(self.get_about_details(), title="About - Accessible Tech Labs India")
                elif sel == 1:
                    webbrowser.open(self.website_url)
                    ui.message("Opening Website...")
                elif sel == 2:
                    webbrowser.open(self.youtube_url)
                    ui.message("Opening YouTube Channel...")
                elif sel == 3:
                    webbrowser.open(self.telegram_url)
                    ui.message("Opening Telegram Channel...")
                elif sel == 4:
                    webbrowser.open(f"mailto:{self.email}")
                    ui.message("Preparing Email...")