import os
import json
import webbrowser
import wx
import ui
from . import telemetry_manager

class LauncherManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()

	def _get_launcher_path(self):
		return os.path.join(os.path.dirname(__file__), "launcher_settings.json")

	def _load_launcher_data(self):
		path = self._get_launcher_path()
		if os.path.exists(path):
			try:
				with open(path, "r", encoding="utf-8") as f:
					return json.load(f)
			except:
				pass
		return {str(i): "" for i in range(10)}

	def _save_launcher_data(self, data):
		try:
			with open(self._get_launcher_path(), "w", encoding="utf-8") as f:
				json.dump(data, f)
		except:
			pass

	def run_slot(self, slot_num):
		data = self._load_launcher_data()
		path = data.get(str(slot_num), "")
		if not path:
			wx.CallAfter(ui.message, f"Slot {slot_num} is empty")
			return
		
		target = path
		if "." in target and not target.startswith(("http://", "https://")) and "\\" not in target:
			target = "https://" + target
			
		try:
			if target.startswith(("http://", "https://")):
				webbrowser.open(target)
			else:
				os.startfile(target)
			self.telemetry.track("Quick Launcher - App Launched")
			wx.CallAfter(ui.message, f"Opening Slot {slot_num}")
		except:
			wx.CallAfter(ui.message, "Error: Could not open")

	def open_menu(self):
		data = self._load_launcher_data()
		options = [f"Slot {i}: {data[str(i)] if data.get(str(i)) else 'Empty'}" for i in range(10)]
		def on_select():
			with wx.SingleChoiceDialog(None, "Select a slot to configure:", "ATL Quick Launcher", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					index = dlg.GetSelection()
					self.configure_slot(index)
		wx.CallAfter(on_select)

	def configure_slot(self, index):
		options = ["Select Application (File)", "Select Folder", "Manual Entry / Web Link", "Clear Slot"]
		def show_menu():
			with wx.SingleChoiceDialog(None, f"Choose action for Slot {index}:", "Configure Slot", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					selection = dlg.GetSelection()
					if selection == 0:
						self._browse_file(index)
					elif selection == 1:
						self._browse_folder(index)
					elif selection == 2:
						self._manual_entry(index)
					elif selection == 3:
						self._clear_slot(index)
		wx.CallAfter(show_menu)

	def _browse_file(self, index):
		def open_file():
			with wx.FileDialog(None, "Select Application or File", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetPath())
		wx.CallAfter(open_file)

	def _browse_folder(self, index):
		def open_dir():
			with wx.DirDialog(None, "Select Folder", style=wx.DD_DEFAULT_STYLE) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetPath())
		wx.CallAfter(open_dir)

	def _manual_entry(self, index):
		data = self._load_launcher_data()
		current = data.get(str(index), "")
		def enter_text():
			with wx.TextEntryDialog(None, "Enter URL or Path:", "Manual Entry", current) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, dlg.GetValue().strip())
		wx.CallAfter(enter_text)

	def _clear_slot(self, index):
		self._update_slot(index, "")
		wx.CallAfter(ui.message, f"Slot {index} cleared")

	def _update_slot(self, index, path):
		data = self._load_launcher_data()
		data[str(index)] = path
		self._save_launcher_data(data)
		if path:
			wx.CallAfter(ui.message, f"Slot {index} updated")