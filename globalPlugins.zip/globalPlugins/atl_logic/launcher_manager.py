import os
import json
import webbrowser
import wx
import ui
import time
import threading
from . import telemetry_manager

class LauncherManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.settings_map = {
			"System: Display Settings": "ms-settings:display",
			"System: Sound & Volume": "ms-settings:sound",
			"System: Notifications": "ms-settings:notifications",
			"System: Power & Sleep": "ms-settings:powersleep",
			"System: Storage Sense": "ms-settings:storagesense",
			"System: About PC": "ms-settings:about",
			"System: Multitasking": "ms-settings:multitasking",
			"Devices: Bluetooth": "ms-settings:bluetooth",
			"Devices: Printers & Scanners": "ms-settings:printers",
			"Devices: Mouse": "ms-settings:mousetouchpad",
			"Devices: Keyboard": "ms-settings:keyboard",
			"Devices: USB": "ms-settings:usb",
			"Network: Wi-Fi": "ms-settings:network-wifi",
			"Network: Ethernet": "ms-settings:network-ethernet",
			"Network: VPN": "ms-settings:network-vpn",
			"Network: Mobile Hotspot": "ms-settings:network-mobilehotspot",
			"Network: Airplane Mode": "ms-settings:network-airplanemode",
			"Network: Proxy": "ms-settings:network-proxy",
			"Personalization: Background": "ms-settings:personalization-background",
			"Personalization: Colors": "ms-settings:personalization-colors",
			"Personalization: Lock Screen": "ms-settings:lockscreen",
			"Personalization: Themes": "ms-settings:themes",
			"Personalization: Taskbar": "ms-settings:taskbar",
			"Apps: Installed Apps": "ms-settings:appsfeatures",
			"Apps: Default Apps": "ms-settings:defaultapps",
			"Apps: Startup Apps": "ms-settings:startupapps",
			"Accounts: Your Info": "ms-settings:yourinfo",
			"Accounts: Email & Accounts": "ms-settings:emailandaccounts",
			"Accounts: Sign-in Options": "ms-settings:signinoptions",
			"Accounts: Family": "ms-settings:family",
			"Time & Language: Date & Time": "ms-settings:dateandtime",
			"Time & Language: Region": "ms-settings:regionlanguage",
			"Time & Language: Speech": "ms-settings:speech",
			"Gaming: Game Bar": "ms-settings:gaming-gamebar",
			"Gaming: Game Mode": "ms-settings:gaming-gamemode",
			"Accessibility: Narrator": "ms-settings:easeofaccess-narrator",
			"Accessibility: Magnifier": "ms-settings:easeofaccess-magnifier",
			"Accessibility: High Contrast": "ms-settings:easeofaccess-highcontrast",
			"Accessibility: Closed Captions": "ms-settings:easeofaccess-closedcaptioning",
			"Accessibility: Keyboard": "ms-settings:easeofaccess-keyboard",
			"Accessibility: Mouse": "ms-settings:easeofaccess-mouse",
			"Security: Windows Security": "ms-settings:windowsdefender",
			"Security: Windows Update": "ms-settings:windowsupdate",
			"Security: Activation": "ms-settings:activation",
			"Security: Recovery": "ms-settings:recovery",
			"Security: For Developers": "ms-settings:developers",
			"Privacy: Location": "ms-settings:privacy-location",
			"Privacy: Camera": "ms-settings:privacy-webcam",
			"Privacy: Microphone": "ms-settings:privacy-microphone"
		}

	def _get_launcher_path(self):
		return os.path.join(os.path.dirname(__file__), "atl_master_settings.json")

	def _load_launcher_data(self):
		path = self._get_launcher_path()
		default_data = {str(i): {"name": "", "items": []} for i in range(10)}
		if os.path.exists(path):
			try:
				with open(path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict) and "launcher_settings" in data:
						loaded = data["launcher_settings"]
						for k, v in loaded.items():
							if isinstance(v, str):
								default_data[k] = {"name": "Legacy Application", "items": [v] if v else []}
							elif isinstance(v, dict):
								default_data[k] = v
						return default_data
			except:
				pass
		return default_data

	def _save_launcher_data(self, launcher_data):
		path = self._get_launcher_path()
		master_data = {}
		if os.path.exists(path):
			try:
				with open(path, "r", encoding="utf-8") as f:
					loaded_data = json.load(f)
					if isinstance(loaded_data, dict):
						master_data = loaded_data
			except:
				pass
		master_data["launcher_settings"] = launcher_data
		try:
			with open(path, "w", encoding="utf-8") as f:
				json.dump(master_data, f)
		except:
			pass

	def run_slot(self, slot_num):
		data = self._load_launcher_data()
		slot_data = data.get(str(slot_num), {})
		items = slot_data.get("items", [])
		name = slot_data.get("name", f"Slot {slot_num}")
		
		if not items:
			wx.CallAfter(ui.message, f"Slot {slot_num} is currently empty.")
			return
		
		wx.CallAfter(ui.message, f"Launching Workspace: {name}")
		threading.Thread(target=self._launch_items, args=(items,), daemon=True).start()

	def _launch_items(self, items):
		for target in items:
			try:
				if target.startswith("ms-settings:"):
					os.startfile(target)
				elif "." in target and not target.startswith(("http://", "https://")) and "\\" not in target:
					webbrowser.open("https://" + target)
				elif target.startswith(("http://", "https://")):
					webbrowser.open(target)
				else:
					os.startfile(target)
			except:
				pass
			time.sleep(1)
		self.telemetry.track("Quick Launcher - App Launched")
		tones.beep(800, 100)

	def open_menu(self):
		data = self._load_launcher_data()
		options = []
		for i in range(10):
			slot_data = data[str(i)]
			if slot_data.get("items"):
				options.append(f"Slot {i}: {slot_data['name']} ({len(slot_data['items'])} items attached)")
			else:
				options.append(f"Slot {i}: Empty")
		
		def on_select():
			with wx.SingleChoiceDialog(None, "Select a workspace slot to configure:", "ATL Smart Workspace Manager", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					index = dlg.GetSelection()
					self.configure_slot(index)
		wx.CallAfter(on_select)

	def configure_slot(self, index):
		data = self._load_launcher_data()
		slot_data = data[str(index)]
		
		if not slot_data.get("items"):
			self._setup_new_workspace(index, data)
		else:
			options = ["Add New Item to Workspace", "Rename Workspace", "Clear Slot"]
			def show_menu():
				with wx.SingleChoiceDialog(None, f"Options for Slot {index} ({slot_data['name']}):", "Workspace Options", options) as dlg:
					if dlg.ShowModal() == wx.ID_OK:
						sel = dlg.GetSelection()
						if sel == 0:
							self._add_item_menu(index, data)
						elif sel == 1:
							self._rename_workspace(index, data)
						elif sel == 2:
							self._clear_slot(index, data)
			wx.CallAfter(show_menu)

	def _setup_new_workspace(self, index, data):
		def ask_name():
			with wx.TextEntryDialog(None, "Enter a friendly name for this Workspace (e.g. My Office Setup):", "New Workspace Creation") as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					name = dlg.GetValue().strip()
					if not name:
						name = f"Workspace {index}"
					data[str(index)]["name"] = name
					self._save_launcher_data(data)
					self._add_item_menu(index, data)
		wx.CallAfter(ask_name)

	def _rename_workspace(self, index, data):
		current_name = data[str(index)].get("name", "")
		def ask_name():
			with wx.TextEntryDialog(None, "Enter new name:", "Rename Workspace", current_name) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					name = dlg.GetValue().strip()
					if name:
						data[str(index)]["name"] = name
						self._save_launcher_data(data)
						wx.CallAfter(ui.message, "Workspace renamed successfully.")
		wx.CallAfter(ask_name)

	def _add_item_menu(self, index, data):
		options = ["Add Application (EXE / File)", "Add Folder", "Add Web Link", "Add Windows Setting"]
		def show_add():
			with wx.SingleChoiceDialog(None, "Select item type to attach to workspace:", "Add to Workspace", options) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					sel = dlg.GetSelection()
					if sel == 0:
						self._browse_file(index, data)
					elif sel == 1:
						self._browse_folder(index, data)
					elif sel == 2:
						self._manual_entry(index, data)
					elif sel == 3:
						self._add_windows_setting(index, data)
		wx.CallAfter(show_add)

	def _browse_file(self, index, data):
		def open_file():
			with wx.FileDialog(None, "Select Application or File", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, data, dlg.GetPath())
		wx.CallAfter(open_file)

	def _browse_folder(self, index, data):
		def open_dir():
			with wx.DirDialog(None, "Select Folder", style=wx.DD_DEFAULT_STYLE) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					self._update_slot(index, data, dlg.GetPath())
		wx.CallAfter(open_dir)

	def _manual_entry(self, index, data):
		def enter_text():
			with wx.TextEntryDialog(None, "Enter Web URL (e.g. youtube.com):", "Add Web Link") as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					val = dlg.GetValue().strip()
					if val:
						self._update_slot(index, data, val)
		wx.CallAfter(enter_text)

	def _add_windows_setting(self, index, data):
		keys = list(self.settings_map.keys())
		def pick_setting():
			with wx.SingleChoiceDialog(None, "Select a Windows Setting:", "System Settings Catalog", keys) as dlg:
				if dlg.ShowModal() == wx.ID_OK:
					sel = dlg.GetSelection()
					setting_name = keys[sel]
					setting_uri = self.settings_map[setting_name]
					self._update_slot(index, data, setting_uri)
		wx.CallAfter(pick_setting)

	def _clear_slot(self, index, data):
		data[str(index)]["name"] = ""
		data[str(index)]["items"] = []
		self._save_launcher_data(data)
		wx.CallAfter(ui.message, f"Slot {index} cleared completely.")

	def _update_slot(self, index, data, path):
		if path:
			data[str(index)]["items"].append(path)
			self._save_launcher_data(data)
			tones.beep(600, 80)
			wx.CallAfter(ui.message, f"Item successfully attached to {data[str(index)]['name']}")