import os
import shutil
import ctypes
import time
import threading
import json
import subprocess
import winreg
import wx
import ui
import tones
import api
from datetime import datetime
from . import telemetry_manager

class CleanManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()
		self.settings_path = os.path.join(os.path.dirname(__file__), "atl_master_settings.json")
		self.is_monitoring = True
		self.username = os.environ.get("USERNAME", "User")
		threading.Thread(target=self._auto_clean_monitor, daemon=True).start()
		threading.Thread(target=self._check_catchup_logic, daemon=True).start()

	def _load_settings(self):
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("auto_cleanup", {})
			except:
				pass
		return {}

	def _save_settings(self, config):
		data = {}
		if os.path.exists(self.settings_path):
			try:
				with open(self.settings_path, "r", encoding="utf-8") as f:
					loaded_data = json.load(f)
					if isinstance(loaded_data, dict):
						data = loaded_data
			except:
				pass
		data["auto_cleanup"] = config
		try:
			with open(self.settings_path, "w", encoding="utf-8") as f:
				json.dump(data, f)
		except:
			pass

	def open_menu(self):
		tones.beep(800, 50)
		options = [
			"1. Smart Browser Optimizer",
			"2. Windows Junk & History Cleaner",
			"3. Deep System Analyzer (Pre-Scan)",
			"4. Empty Recycle Bin",
			"5. Execute Deep Clean All",
			"6. Auto Cleanup Subsystem"
		]
		with wx.SingleChoiceDialog(None, "ATL Enterprise System Cleaner:", "ATL System Cleaner V2.0", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 2:
					threading.Thread(target=self._scan_only, daemon=True).start()
				elif sel == 5:
					wx.CallAfter(self._handle_auto_cleanup_menu)
				else:
					self._prepare_clean(sel)

	def _handle_auto_cleanup_menu(self):
		config = self._load_settings()
		if config.get("configured", False):
			opts = ["Edit Existing Task", "Delete Existing Task"]
			with wx.SingleChoiceDialog(None, "An active Auto Cleanup task is already registered.", "Manage Auto Cleanup", opts) as m_dlg:
				if m_dlg.ShowModal() == wx.ID_OK:
					if m_dlg.GetSelection() == 0:
						wx.CallAfter(self._setup_auto_cleanup, config)
					else:
						self._save_settings({})
						tones.beep(500, 100)
						wx.MessageBox("Auto Cleanup task successfully deleted.", "Task Removed", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
		else:
			wx.CallAfter(self._setup_auto_cleanup)

	def _get_targets(self, selection):
		local_app = os.environ.get('LOCALAPPDATA', '')
		roaming_app = os.environ.get('APPDATA', '')
		win_dir = os.environ.get('SystemRoot', 'C:\\Windows')
		sys_temp = os.environ.get('TEMP')
		prog_data = os.environ.get('ProgramData', 'C:\\ProgramData')

		user_targets = []
		admin_targets = []

		b_targets = [
			(os.path.join(local_app, "Google\\Chrome\\User Data\\Default\\Cache"), "Chrome Cache"),
			(os.path.join(local_app, "Microsoft\\Edge\\User Data\\Default\\Cache"), "Edge Cache"),
			(os.path.join(local_app, "BraveSoftware\\Brave-Browser\\User Data\\Default\\Cache"), "Brave Cache")
		]
		
		ff_path = os.path.join(roaming_app, "Mozilla\\Firefox\\Profiles")
		if os.path.exists(ff_path):
			try:
				for p in os.listdir(ff_path):
					user_targets.append((os.path.join(ff_path, p, "cache2"), f"Firefox Cache ({p[:4]})"))
			except:
				pass

		w_user_targets = [
			(sys_temp, "User Temp"),
			(os.path.join(local_app, "CrashDumps"), "Crash Dumps"),
			(os.path.join(roaming_app, "Microsoft\\Windows\\Recent"), "Recent History")
		]

		w_admin_targets = [
			(os.path.join(win_dir, "Temp"), "System Temp"),
			(os.path.join(win_dir, "Prefetch"), "Windows Prefetch"),
			(os.path.join(win_dir, "SoftwareDistribution\\Download"), "Windows Update Cache"),
			(os.path.join(win_dir, "Logs\\CBS"), "Windows CBS Logs"),
			(os.path.join(prog_data, "Microsoft\\Windows\\WER\\ReportArchive"), "System Error Reports")
		]

		if selection == 0:
			user_targets.extend(b_targets)
		elif selection == 1:
			user_targets.extend(w_user_targets)
			admin_targets.extend(w_admin_targets)
		elif selection == 4 or selection == 99:
			user_targets.extend(b_targets)
			user_targets.extend(w_user_targets)
			admin_targets.extend(w_admin_targets)

		return user_targets, admin_targets

	def _clear_run_history(self):
		try:
			key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU", 0, winreg.KEY_ALL_ACCESS)
			idx = 0
			while True:
				try:
					val_name = winreg.EnumValue(key, idx)[0]
					if val_name.lower() != "(default)":
						winreg.DeleteValue(key, val_name)
					else:
						idx += 1
				except OSError:
					break
			winreg.CloseKey(key)
		except:
			pass

	def _scan_only(self):
		self.telemetry.track("System Cleaner - Deep Pre-Scan")
		wx.CallAfter(ui.message, "Deep scanning system areas, please wait.")
		user_targets, admin_targets = self._get_targets(4)
		all_targets = user_targets + admin_targets
		
		total_bytes = 0
		report_lines = []

		for path, name in all_targets:
			cat_bytes = 0
			if path and os.path.exists(path):
				for root, dirs, files in os.walk(path):
					for f in files:
						fp = os.path.join(root, f)
						try:
							cat_bytes += os.path.getsize(fp)
						except:
							pass
			if cat_bytes > 0:
				mb = round(cat_bytes / (1024 * 1024), 2)
				report_lines.append(f"{name}: {mb} MB")
				total_bytes += cat_bytes

		total_mb = round(total_bytes / (1024 * 1024), 2)
		if total_mb > 1024:
			total_str = f"{round(total_mb / 1024, 2)} GB"
		else:
			total_str = f"{total_mb} MB"

		report_text = "System Deep Scan Complete.\n\n" + "\n".join(report_lines) + f"\n\nTotal Junk Found: {total_str}\n\nDo you want to execute Clean All now?"
		tones.beep(1000, 150)
		
		def show_result():
			dlg = wx.MessageDialog(None, report_text, "ATL Deep Analyzer Report", wx.YES_NO | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
			res = dlg.ShowModal()
			dlg.Destroy()
			if res == wx.ID_YES:
				self._prepare_clean(4)
		
		wx.CallAfter(show_result)

	def _prepare_clean(self, selection, is_silent=False, is_auto_scheduled=False):
		user_t, admin_t = self._get_targets(selection)
		
		is_admin = False
		try:
			is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
		except:
			pass

		if admin_t and not is_admin:
			if is_auto_scheduled:
				msg = (
					f"Dear {self.username},\n\n"
					f"Your scheduled Deep Auto-Cleanup task is ready to execute. "
					f"We require Administrator privileges to deeply optimize the system folders safely.\n\n"
					f"Do you want to grant permission now?"
				)
				dlg = wx.MessageDialog(None, msg, "ATL Scheduled Cleanup Ready", wx.YES_NO | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
			elif not is_silent:
				dlg = wx.MessageDialog(None, "Deep cleaning requires Administrator permission. The UAC prompt will appear. Do you want to proceed?", "Administrator Rights Required", wx.YES_NO | wx.ICON_WARNING | wx.STAY_ON_TOP)
			else:
				dlg = None
				admin_t = []

			if dlg:
				tones.beep(800, 150)
				res = dlg.ShowModal()
				dlg.Destroy()
				if res == wx.ID_YES:
					cmd_str = '/c ' + ' & '.join([f'del /q /f /s "{p}\\*" >nul 2>&1' for p, n in admin_t])
					ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", cmd_str, None, 0)
					if not is_silent or is_auto_scheduled:
						wx.CallAfter(ui.message, "Administrator access granted. Deep cleaning in progress.")
				else:
					if not is_silent or is_auto_scheduled:
						wx.CallAfter(ui.message, "Skipping locked system folders.")
					admin_t = []

		final_targets = user_t + admin_t
		threading.Thread(target=self._clean_worker, args=(selection, final_targets, is_silent, is_auto_scheduled), daemon=True).start()

	def _clean_worker(self, selection, targets, is_silent, is_auto_scheduled):
		if not is_silent or is_auto_scheduled:
			self.telemetry.track("System Cleaner - Execution")
			wx.CallAfter(ui.message, "Cleaning process initiated.")

		actual_bytes = 0
		dlg_box = []

		if not is_silent or is_auto_scheduled:
			def create_dialog():
				dlg = wx.ProgressDialog("ATL Enterprise Cleaner", "Optimizing...", maximum=max(1, len(targets)*100), parent=None, style=wx.PD_SMOOTH | wx.PD_AUTO_HIDE | wx.STAY_ON_TOP)
				dlg.Show()
				dlg_box.append(dlg)
			wx.CallAfter(create_dialog)
			time.sleep(0.5)

		last_beep = time.time()

		for i, (path, name) in enumerate(targets):
			if not path or not os.path.exists(path):
				continue

			if not is_silent or is_auto_scheduled:
				if dlg_box: wx.CallAfter(dlg_box[0].Update, i * 100, f"Cleaning {name}...")

			for root, dirs, files in os.walk(path):
				for f in files:
					if (not is_silent or is_auto_scheduled) and (time.time() - last_beep >= 1.0):
						tones.beep(1000, 50)
						last_beep = time.time()
					fp = os.path.join(root, f)
					try:
						size = os.path.getsize(fp)
						os.remove(fp)
						actual_bytes += size
					except:
						pass
				for d in dirs:
					dp = os.path.join(root, d)
					try:
						shutil.rmtree(dp)
					except:
						pass
			time.sleep(0.1)

		if selection in [1, 4, 99]:
			self._clear_run_history()

		if selection in [3, 4, 99]:
			try:
				main_hwnd = api.getDesktopObject().windowHandle
				if ctypes.windll.shell32.SHEmptyRecycleBinW(main_hwnd, None, 7) != 0:
					ctypes.windll.shell32.SHEmptyRecycleBinW(0, None, 7)
			except:
				pass

		if selection in [4, 99]:
			try:
				subprocess.run(["ipconfig", "/flushdns"], creationflags=0x08000000)
			except:
				pass

		if not is_silent or is_auto_scheduled:
			wx.CallAfter(lambda: dlg_box[0].Destroy() if dlg_box else None)
			mb = round(actual_bytes / (1024 * 1024), 2)
			final_msg = f"Optimization Complete!\nRecovered Storage: {round(mb/1024, 2)} GB" if mb > 1024 else f"Optimization Complete!\nRecovered Storage: {mb} MB"
			wx.CallAfter(ui.message, "Optimization complete")
			tones.beep(800, 100)
			tones.beep(1200, 150)
			wx.CallAfter(wx.MessageBox, final_msg, "ATL System Cleaner", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)

	def _setup_auto_cleanup(self, edit_data=None):
		data = edit_data if edit_data else {}
		dlg = wx.Dialog(None, title="ATL Auto Cleanup Setup")
		sz = wx.BoxSizer(wx.VERTICAL)

		freq_cb = wx.ComboBox(dlg, choices=["Daily", "Weekly", "Monthly"], style=wx.CB_READONLY)
		freq_cb.SetValue(data.get("frequency", "Daily"))
		sz.Add(wx.StaticText(dlg, label="Select Execution Frequency:"), 0, wx.LEFT | wx.TOP, 5)
		sz.Add(freq_cb, 0, wx.EXPAND | wx.ALL, 5)

		time_sz = wx.BoxSizer(wx.HORIZONTAL)
		h_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(24)], style=wx.CB_READONLY)
		h_cb.SetValue(data.get("hour", "14"))
		m_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(60)], style=wx.CB_READONLY)
		m_cb.SetValue(data.get("minute", "00"))
		time_sz.Add(wx.StaticText(dlg, label="Hour:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, 5)
		time_sz.Add(h_cb, 0, wx.ALL, 5)
		time_sz.Add(wx.StaticText(dlg, label="Minute:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, 5)
		time_sz.Add(m_cb, 0, wx.ALL, 5)
		sz.Add(wx.StaticText(dlg, label="Select Execution Time:"), 0, wx.LEFT | wx.TOP, 5)
		sz.Add(time_sz, 0, wx.ALL, 5)

		deep_chk = wx.CheckBox(dlg, label="Include Deep System Files (Requires Administrator UAC prompt at execution)")
		deep_chk.SetValue(data.get("deep_mode", False))
		sz.Add(deep_chk, 0, wx.ALL, 5)

		btn_sz = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
		sz.Add(btn_sz, 0, wx.CENTER | wx.ALL, 10)
		dlg.SetSizer(sz)
		dlg.Fit()

		if dlg.ShowModal() == wx.ID_OK:
			new_cfg = {
				"configured": True,
				"frequency": freq_cb.GetValue(),
				"hour": h_cb.GetValue(),
				"minute": m_cb.GetValue(),
				"deep_mode": deep_chk.GetValue(),
				"last_run": data.get("last_run", "")
			}
			self._save_settings(new_cfg)
			if new_cfg["deep_mode"]:
				wx.MessageBox("Warning: Deep mode is enabled. At the scheduled time, a UAC prompt will appear asking for Administrator permissions.", "Security Notice", wx.OK | wx.ICON_WARNING | wx.STAY_ON_TOP)
			else:
				wx.MessageBox("Auto Cleanup task successfully registered.", "Success", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)
			self.telemetry.track("System Cleaner - Auto Clean Configured")
		dlg.Destroy()

	def _auto_clean_monitor(self):
		while self.is_monitoring:
			config = self._load_settings()
			if config.get("configured", False):
				now = datetime.now()
				today_str = now.strftime("%Y-%m-%d")
				t_h = int(config.get("hour", "14"))
				t_m = int(config.get("minute", "00"))
				
				should_run = False
				if config["frequency"] == "Daily":
					should_run = True
				elif config["frequency"] == "Weekly" and now.weekday() == 0:
					should_run = True
				elif config["frequency"] == "Monthly" and now.day == 1:
					should_run = True

				if should_run and config.get("last_run") != today_str:
					if now.hour == t_h and now.minute == t_m and now.second == 0:
						config["last_run"] = today_str
						self._save_settings(config)
						wx.CallAfter(self._prepare_clean, 4 if config.get("deep_mode") else 0, is_silent=not config.get("deep_mode"), is_auto_scheduled=True)
			time.sleep(1)

	def _check_catchup_logic(self):
		time.sleep(10)
		config = self._load_settings()
		if config.get("configured", False):
			now = datetime.now()
			today_str = now.strftime("%Y-%m-%d")
			t_h = int(config.get("hour", "14"))
			t_m = int(config.get("minute", "00"))

			should_run = False
			if config["frequency"] == "Daily":
				should_run = True
			elif config["frequency"] == "Weekly" and now.weekday() == 0:
				should_run = True
			elif config["frequency"] == "Monthly" and now.day == 1:
				should_run = True

			if should_run and config.get("last_run") != today_str:
				if now.hour > t_h or (now.hour == t_h and now.minute > t_m):
					config["last_run"] = today_str
					self._save_settings(config)
					wx.CallAfter(self._prepare_clean, 4 if config.get("deep_mode") else 0, is_silent=not config.get("deep_mode"), is_auto_scheduled=True)