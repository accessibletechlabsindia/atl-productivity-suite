import os
import shutil
import ctypes
import time
import threading
import wx
import ui
import tones
import api
from . import telemetry_manager

class CleanManager:
	def __init__(self):
		self.telemetry = telemetry_manager.TelemetryManager()

	def open_menu(self):
		tones.beep(800, 50)
		options = [
			"1. Windows Junk (Temp and Prefetch)",
			"2. Google Chrome Cache",
			"3. Microsoft Edge Cache",
			"4. Empty Recycle Bin",
			"5. Deep Clean All"
		]
		with wx.SingleChoiceDialog(None, "Select Cleaning Task:", "ATL System Cleaner", options) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				self._prepare_clean(sel)

	def _prepare_clean(self, selection):
		is_admin = False
		try:
			is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
		except:
			pass

		local_app_data = os.environ.get('LOCALAPPDATA', '')
		win_dir = os.environ.get('SystemRoot', 'C:\\Windows')
		sys_temp = os.environ.get('TEMP')
		win_temp = os.path.join(win_dir, 'Temp')
		prefetch = os.path.join(win_dir, 'Prefetch')
		chrome_cache = os.path.join(local_app_data, "Google\\Chrome\\User Data\\Default\\Cache")
		edge_cache = os.path.join(local_app_data, "Microsoft\\Edge\\User Data\\Default\\Cache")

		targets = []
		admin_targets = []

		if selection in [0, 4]:
			targets.append((sys_temp, "User Temp"))
			if is_admin:
				targets.append((win_temp, "System Temp"))
				targets.append((prefetch, "Prefetch"))
			else:
				admin_targets.append((win_temp, "System Temp"))
				admin_targets.append((prefetch, "Prefetch"))

		if selection in [1, 4]:
			targets.append((chrome_cache, "Chrome Cache"))
		if selection in [2, 4]:
			targets.append((edge_cache, "Edge Cache"))

		if admin_targets and not is_admin:
			dlg = wx.MessageDialog(None, "Deep cleaning requires Administrator permission to clean Windows Temp and Prefetch folders safely. Do you want to grant permission now?", "Administrator Rights Required", wx.YES_NO | wx.ICON_WARNING | wx.STAY_ON_TOP)
			res = dlg.ShowModal()
			dlg.Destroy()
			if res == wx.ID_YES:
				cmd_str = '/c ' + ' & '.join([f'del /q /f /s "{p}\\*" >nul 2>&1' for p, n in admin_targets])
				ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", cmd_str, None, 0)
				wx.CallAfter(ui.message, "Administrator access granted. Cleaning deep system files.")
			else:
				wx.CallAfter(ui.message, "Skipping locked system folders.")

		threading.Thread(target=self._clean_worker, args=(selection, targets), daemon=True).start()

	def _clean_worker(self, selection, targets):
		if selection == 0:
			self.telemetry.track("System Cleaner - Windows Junk")
		elif selection == 1:
			self.telemetry.track("System Cleaner - Chrome Cache")
		elif selection == 2:
			self.telemetry.track("System Cleaner - Edge Cache")
		elif selection == 3:
			self.telemetry.track("System Cleaner - Empty Recycle Bin")
		elif selection == 4:
			self.telemetry.track("System Cleaner - Deep Clean All")

		wx.CallAfter(ui.message, "Cleaning started")
		actual_bytes_cleared = 0
		dlg_box = []

		def create_dialog():
			dlg = wx.ProgressDialog("ATL System Cleaner", "Starting...", maximum=max(1, len(targets)*100), parent=None, style=wx.PD_SMOOTH | wx.PD_AUTO_HIDE | wx.STAY_ON_TOP)
			dlg.Show()
			dlg_box.append(dlg)

		wx.CallAfter(create_dialog)
		time.sleep(0.5)
		last_beep_time = time.time()

		for i, (path, name) in enumerate(targets):
			if not path or not os.path.exists(path):
				continue

			def update_msg(msg, val):
				if dlg_box: dlg_box[0].Update(val, msg)

			wx.CallAfter(update_msg, f"Cleaning {name}...", i * 100)
			wx.CallAfter(ui.message, f"Cleaning {name}")

			for root, dirs, files in os.walk(path):
				for f in files:
					current_time = time.time()
					if current_time - last_beep_time >= 1.0:
						tones.beep(1000, 50)
						last_beep_time = current_time

					file_path = os.path.join(root, f)
					try:
						size = os.path.getsize(file_path)
						os.remove(file_path)
						actual_bytes_cleared += size
					except:
						pass
				
				for d in dirs:
					dir_path = os.path.join(root, d)
					try:
						shutil.rmtree(dir_path)
					except:
						pass
			time.sleep(0.5)

		if selection in [3, 4]:
			wx.CallAfter(update_msg, "Emptying Recycle Bin...", len(targets) * 100)
			wx.CallAfter(ui.message, "Emptying Recycle Bin")
			try:
				main_hwnd = api.getDesktopObject().windowHandle
				res = ctypes.windll.shell32.SHEmptyRecycleBinW(main_hwnd, None, 7)
				if res == 0:
					tones.beep(1000, 50)
				else:
					ctypes.windll.shell32.SHEmptyRecycleBinW(0, None, 7)
			except:
				pass

		def close_dialog():
			if dlg_box: dlg_box[0].Destroy()

		wx.CallAfter(close_dialog)

		mb = round(actual_bytes_cleared / (1024 * 1024), 2)
		if mb > 1024:
			final_msg = f"Done! Real cleared memory: {round(mb/1024, 2)} GB."
		else:
			final_msg = f"Done! Real cleared memory: {mb} MB."

		wx.CallAfter(ui.message, final_msg)
		tones.beep(800, 100)
		tones.beep(1000, 150)
		wx.CallAfter(wx.MessageBox, final_msg, "Cleaning Complete", wx.OK | wx.ICON_INFORMATION | wx.STAY_ON_TOP)