import os
import json
import time
import threading
import subprocess
import wx
import ctypes
from datetime import datetime, timedelta
import tones
from . import telemetry_manager

class PowerManager:
	def __init__(self):
		self.addon_dir = os.path.dirname(__file__)
		self.config_path = os.path.join(self.addon_dir, "atl_master_settings.json")
		self.tasks = self.load_tasks()
		self.is_monitoring = True
		self.username = os.environ.get("USERNAME", "System Administrator")
		self.mci = ctypes.windll.winmm.mciSendStringW
		self.telemetry = telemetry_manager.TelemetryManager()
		threading.Thread(target=self._monitor, daemon=True).start()

	def load_tasks(self):
		if os.path.exists(self.config_path):
			try:
				with open(self.config_path, "r") as f:
					data = json.load(f)
					if isinstance(data, dict):
						return data.get("power_tasks", [])
			except:
				return []
		return []

	def save_tasks(self):
		data = {}
		if os.path.exists(self.config_path):
			try:
				with open(self.config_path, "r") as f:
					loaded_data = json.load(f)
					if isinstance(loaded_data, dict):
						data = loaded_data
			except:
				pass
		data["power_tasks"] = self.tasks
		try:
			with open(self.config_path, "w") as f:
				json.dump(data, f)
		except:
			pass

	def _play_warning_sound(self):
		sound_path = os.path.join(self.addon_dir, "Sounds", "power_manager.mp3")
		if os.path.exists(sound_path):
			alias = f"pwr_{int(time.time() * 1000)}"
			self.mci(f'open "{sound_path}" type mpegvideo alias {alias}', None, 0, 0)
			self.mci(f'play {alias} wait', None, 0, 0)
			self.mci(f'close {alias}', None, 0, 0)

	def _monitor(self):
		while self.is_monitoring:
			now = datetime.now()
			today_str = now.strftime("%Y-%m-%d")
			
			for task in self.tasks[:]:
				should_run = False
				if task["recurrence"] == "Once":
					should_run = True
				elif task["recurrence"] == "Daily":
					should_run = True
				elif task["recurrence"] == "Weekly" and now.weekday() == task.get("weekday", -1):
					should_run = True
				elif task["recurrence"] == "Monthly" and now.day == task.get("day", -1):
					should_run = True

				if not should_run or task.get("last_run") == today_str:
					continue

				target_dt = now.replace(hour=int(task["hour"]), minute=int(task["minute"]), second=0, microsecond=0)
				warn_dt = target_dt - timedelta(minutes=int(task["warning_min"]))
				cd_dt = target_dt - timedelta(seconds=10)
				end_dt = target_dt + timedelta(minutes=1)

				if now >= end_dt and task.get("last_run") != today_str:
					task["last_run"] = today_str
					task["last_warn"] = today_str
					task["last_cd"] = today_str
					if task["recurrence"] == "Once":
						if task in self.tasks:
							self.tasks.remove(task)
					self.save_tasks()
					continue

				if warn_dt <= now < target_dt and task.get("last_warn") != today_str:
					task["last_warn"] = today_str
					self.save_tasks()
					threading.Thread(target=self._play_warning_sound, daemon=True).start()
					wx.CallAfter(self._show_warning, task)

				if cd_dt <= now < end_dt and task.get("last_cd") != today_str:
					task["last_cd"] = today_str
					task["last_run"] = today_str
					if task["recurrence"] == "Once":
						if task in self.tasks:
							self.tasks.remove(task)
					self.save_tasks()
					threading.Thread(target=self._countdown_and_execute, args=(task["action"],), daemon=True).start()
			
			time.sleep(1)

	def _show_warning(self, task):
		act = task["action"].upper()
		mins = task["warning_min"]
		label = f"{mins} Minute" if mins == 1 else f"{mins} Minutes"
		time_str = f"{str(task['hour']).zfill(2)}:{str(task['minute']).zfill(2)}"
		
		msg = (
			f"ATL Power Management System: Scheduled Action Pending\n\n"
			f"Dear {self.username},\n\n"
			f"This is an automated administration alert from the ATL Power Scheduler. "
			f"A system {act} is officially scheduled to initiate at {time_str}, which is in exactly {label}.\n\n"
			f"IMMEDIATE ACTION REQUIRED:\n"
			f"You are strongly advised to immediately save all ongoing work, close active applications, "
			f"and safely detach external storage devices. If you are executing critical tasks, "
			f"please complete them before the timer expires.\n\n"
			f"OFFICIAL DISCLAIMER:\n"
			f"Accessible Tech Labs India assumes ZERO LIABILITY for data loss, file corruption, "
			f"or unsaved document erasure resulting from this scheduled action. "
			f"By using this utility, you accept full responsibility for your data. "
			f"Please proceed to save your work immediately."
		)
		wx.MessageBox(msg, f"ATL System Alert - {act}", wx.OK | wx.ICON_WARNING | wx.STAY_ON_TOP)

	def _countdown_and_execute(self, action):
		for i in range(10, 0, -1):
			if i > 5:
				tones.beep(400, 300)
				time.sleep(0.7)
			elif i > 1:
				tones.beep(600, 200)
				time.sleep(0.8)
			else:
				tones.beep(1000, 800)
				time.sleep(0.2)
		
		if action == "Shutdown":
			subprocess.run(["shutdown", "/s", "/f", "/t", "0"], creationflags=0x08000000)
		elif action == "Restart":
			subprocess.run(["shutdown", "/r", "/f", "/t", "0"], creationflags=0x08000000)
		elif action == "Sleep":
			ctypes.windll.PowrProf.SetSuspendState(0, 1, 0)

	def open_menu(self):
		opts = ["Add Power Task", "View/Edit Scheduled Tasks"]
		with wx.SingleChoiceDialog(None, "Select an option:", "ATL Power Scheduler", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				sel = dlg.GetSelection()
				if sel == 0:
					wx.CallAfter(self.set_task_dialog)
				elif sel == 1:
					wx.CallAfter(self.manage_tasks_dialog)

	def set_task_dialog(self, edit_idx=None):
		data = self.tasks[edit_idx] if edit_idx is not None else {}
		dlg = wx.Dialog(None, title="ATL Power Scheduler - Task Setup")
		sz = wx.BoxSizer(wx.VERTICAL)

		sz.Add(wx.StaticText(dlg, label="Select Power Action:"), 0, wx.ALL, 5)
		act_cb = wx.ComboBox(dlg, choices=["Shutdown", "Restart", "Sleep"], style=wx.CB_READONLY)
		act_cb.SetName("Select Power Action")
		act_cb.SetSelection(0)
		if "action" in data: act_cb.SetValue(data["action"])
		sz.Add(act_cb, 0, wx.EXPAND | wx.ALL, 5)

		sz.Add(wx.StaticText(dlg, label="Set Hour (00-23):"), 0, wx.ALL, 5)
		h_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(24)], style=wx.CB_READONLY)
		h_cb.SetName("Set Hour")
		h_cb.SetSelection(0)
		if "hour" in data: h_cb.SetValue(data["hour"])
		sz.Add(h_cb, 0, wx.EXPAND | wx.ALL, 5)

		sz.Add(wx.StaticText(dlg, label="Set Minute (00-59):"), 0, wx.ALL, 5)
		m_cb = wx.ComboBox(dlg, choices=[str(i).zfill(2) for i in range(60)], style=wx.CB_READONLY)
		m_cb.SetName("Set Minute")
		m_cb.SetSelection(0)
		if "minute" in data: m_cb.SetValue(data["minute"])
		sz.Add(m_cb, 0, wx.EXPAND | wx.ALL, 5)

		sz.Add(wx.StaticText(dlg, label="Select Frequency:"), 0, wx.ALL, 5)
		rep_cb = wx.ComboBox(dlg, choices=["Once", "Daily", "Weekly", "Monthly"], style=wx.CB_READONLY)
		rep_cb.SetName("Select Frequency")
		rep_cb.SetSelection(0)
		if "recurrence" in data: rep_cb.SetValue(data["recurrence"])
		sz.Add(rep_cb, 0, wx.EXPAND | wx.ALL, 5)

		sz.Add(wx.StaticText(dlg, label="Warning Time Before Action:"), 0, wx.ALL, 5)
		warn_labels = ["1 Minute", "2 Minutes", "3 Minutes", "4 Minutes", "5 Minutes"]
		warn_cb = wx.ComboBox(dlg, choices=warn_labels, style=wx.CB_READONLY)
		warn_cb.SetName("Warning Time Before Action")
		warn_cb.SetSelection(4)
		if "warning_min" in data: warn_cb.SetSelection(int(data["warning_min"]) - 1)
		sz.Add(warn_cb, 0, wx.EXPAND | wx.ALL, 5)

		btn_sz = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
		ok_btn = dlg.FindWindowById(wx.ID_OK)
		if ok_btn:
			ok_btn.SetLabel("Schedule Task")
			ok_btn.SetName("Schedule Task Button")
		sz.Add(btn_sz, 0, wx.CENTER | wx.ALL, 10)

		dlg.SetSizer(sz)
		dlg.Fit()

		def on_ok(evt):
			new_h = int(h_cb.GetValue())
			new_m = int(m_cb.GetValue())
			new_total = new_h * 60 + new_m
			conflict = False
			current_tasks = self.tasks[:]
			
			for i, t in enumerate(current_tasks):
				if edit_idx is not None and i == edit_idx:
					continue
				t_total = int(t["hour"]) * 60 + int(t["minute"])
				diff = abs(new_total - t_total)
				if diff < 5 or diff > (24 * 60 - 5):
					conflict = True
					break
			
			if conflict:
				tones.beep(400, 150)
				wx.MessageBox("Scheduling conflict detected. Another task is already scheduled within 5 minutes of your selected time. Please maintain a minimum gap of 5 minutes to ensure system stability.", "ATL Security Alert", wx.OK | wx.ICON_ERROR | wx.STAY_ON_TOP)
				return
			evt.Skip()

		if ok_btn:
			ok_btn.Bind(wx.EVT_BUTTON, on_ok)

		if dlg.ShowModal() == wx.ID_OK:
			new_task = {
				"action": act_cb.GetValue(),
				"hour": h_cb.GetValue(),
				"minute": m_cb.GetValue(),
				"recurrence": rep_cb.GetValue(),
				"warning_min": warn_cb.GetSelection() + 1,
				"weekday": datetime.now().weekday(),
				"day": datetime.now().day,
				"last_run": "",
				"last_warn": "",
				"last_cd": ""
			}
			if edit_idx is not None:
				self.tasks[edit_idx] = new_task
			else:
				self.tasks.append(new_task)
			self.save_tasks()
			self.telemetry.track("Power Manager - Task Scheduled")
			tones.beep(800, 100)
			tones.beep(1200, 150)
			wx.MessageBox("Task successfully registered by Accessible Tech Labs India", "Success", wx.OK | wx.ICON_INFORMATION)
		
		dlg.Destroy()

	def manage_tasks_dialog(self):
		if not self.tasks:
			wx.MessageBox("No scheduled tasks found.", "Manage Tasks", wx.OK | wx.ICON_INFORMATION)
			return
		opts = [f"{t['action']} at {t['hour']}:{t['minute']} ({t['recurrence']})" for t in self.tasks]
		with wx.SingleChoiceDialog(None, "Select a task to manage:", "Manage Power Tasks", opts) as dlg:
			if dlg.ShowModal() == wx.ID_OK:
				idx = dlg.GetSelection()
				m_opts = ["Modify This Task", "Remove This Task"]
				with wx.SingleChoiceDialog(None, "Choose an action:", "Task Options", m_opts) as m_dlg:
					if m_dlg.ShowModal() == wx.ID_OK:
						if m_dlg.GetSelection() == 0:
							wx.CallAfter(self.set_task_dialog, idx)
						else:
							self.tasks.pop(idx)
							self.save_tasks()
							self.telemetry.track("Power Manager - Task Deleted")
							tones.beep(500, 100)
							wx.MessageBox("Task removed successfully.", "Deleted", wx.OK | wx.ICON_INFORMATION)